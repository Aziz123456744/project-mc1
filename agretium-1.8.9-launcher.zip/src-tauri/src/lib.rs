use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashSet;
use std::fs;
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use sysinfo::{Pid, System};
use tauri::Manager;
use zip::ZipArchive;

const MOJANG_MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const MOJANG_189_FALLBACK_URL: &str =
    "https://piston-meta.mojang.com/v1/packages/d546f1707a3f2b7d034eece5ea2e311eda875787/1.8.9.json";

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct LauncherSettings {
    pub version: String,
    pub account: String,
    pub optifine: bool,
    pub beta: bool,
    pub ram_mb: u64,
    pub mc_path: String,
    pub java_path: String,
    pub resolution: String,
    pub new_gc: bool,
    pub minimize_on_launch: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct OrnitheConfig {
    pub enabled: bool,
    #[serde(rename = "loaderVersion")]
    pub loader_version: String,
    #[serde(rename = "calamusVersion")]
    pub calamus_version: String,
}

impl Default for OrnitheConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            loader_version: "0.20.1".to_string(),
            calamus_version: "1.8.9".to_string(),
        }
    }
}

#[derive(Debug, Serialize)]
pub struct SystemInfo {
    pub total_ram_mb: u64,
}

#[derive(Debug, Serialize)]
pub struct DefaultPaths {
    pub mc_path: String,
    pub java_path: String,
    pub config_path: String,
}

#[derive(Debug, Serialize)]
pub struct PreflightStatus {
    #[serde(rename = "javaOk")]
    pub java_ok: bool,
    #[serde(rename = "jarOk")]
    pub jar_ok: bool,
    #[serde(rename = "assetsOk")]
    pub assets_ok: bool,
    #[serde(rename = "ornitheOk")]
    pub ornithe_ok: bool,
    #[serde(rename = "argentumOk")]
    pub argentum_ok: bool,
    #[serde(rename = "needsDownload")]
    pub needs_download: bool,
    #[serde(rename = "missingArtifacts")]
    pub missing_artifacts: Vec<String>,
    #[serde(rename = "javaBin")]
    pub java_bin: String,
    #[serde(rename = "clientJar")]
    pub client_jar: String,
    #[serde(rename = "checkedAt")]
    pub checked_at: String,
}

#[derive(Debug, Serialize, Clone)]
pub struct DownloadArtifact {
    pub id: String,
    pub label: String,
    #[serde(rename = "fileName")]
    pub file_name: String,
    #[serde(rename = "sizeLabel")]
    pub size_label: String,
    pub status: String,
    pub group: String,
}

#[derive(Debug, Serialize, Clone)]
pub struct VersionDownloadStatus {
    pub state: String,
    pub percent: u8,
    #[serde(rename = "currentArtifact")]
    pub current_artifact: Option<String>,
    #[serde(rename = "completedCount")]
    pub completed_count: usize,
    #[serde(rename = "totalCount")]
    pub total_count: usize,
    pub artifacts: Vec<DownloadArtifact>,
    pub error: Option<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ModJarFile {
    #[serde(rename = "fileName")]
    pub file_name: String,
    #[serde(rename = "baseName")]
    pub base_name: String,
    #[serde(rename = "displayName")]
    pub display_name: String,
    pub enabled: bool,
    #[serde(rename = "sizeBytes")]
    pub size_bytes: u64,
    #[serde(rename = "isCoreArgentum")]
    pub is_core_argentum: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct LaunchHistoryEntry {
    pub id: String,
    pub timestamp: String,
    pub version: String,
    pub account: String,
    pub ram_mb: u64,
    pub optifine: bool,
    pub resolution: String,
    pub command: String,
    pub status: String,
    pub message: String,
    #[serde(rename = "serverAddress")]
    pub server_address: Option<String>,
    #[serde(rename = "launchDurationMs")]
    pub launch_duration_ms: Option<u64>,
}

#[derive(Debug, Serialize)]
pub struct LaunchResponse {
    pub ok: bool,
    pub message: String,
    pub command: String,
    pub args: Vec<String>,
    #[serde(rename = "javaBin")]
    pub java_bin: String,
    #[serde(rename = "clientJar")]
    pub client_jar: String,
    pub minimized: bool,
    #[serde(rename = "historyEntry")]
    pub history_entry: LaunchHistoryEntry,
}

#[derive(Debug, Serialize, Clone)]
pub struct JvmLogEntry {
    pub id: String,
    pub time: String,
    pub level: String,
    pub thread: String,
    pub message: String,
}

#[derive(Debug, Serialize)]
pub struct JvmStatusSnapshot {
    pub running: bool,
    pub pid: Option<u32>,
    pub version: String,
    pub xmx_mb: u64,
    pub xms_mb: u64,
    pub allocated_mb: u64,
    pub used_mb: u64,
    pub gc_algorithm: String,
    pub xmx_flag: String,
    pub xmx_verified: bool,
    pub host_total_ram_mb: u64,
    pub host_free_ram_mb: u64,
    pub uptime_seconds: u64,
    pub gc_collections: u64,
    pub timestamp: String,
    pub logs: Vec<JvmLogEntry>,
}

#[derive(Debug, Serialize)]
pub struct DirectoryEntry {
    pub name: String,
    pub path: String,
    #[serde(rename = "isDirectory")]
    pub is_directory: bool,
    pub hint: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct DirectoryPreset {
    pub label: String,
    pub path: String,
    pub description: String,
}

#[derive(Debug, Serialize)]
pub struct DirectoryListing {
    #[serde(rename = "currentPath")]
    pub current_path: String,
    #[serde(rename = "parentPath")]
    pub parent_path: Option<String>,
    pub entries: Vec<DirectoryEntry>,
    pub presets: Vec<DirectoryPreset>,
}

struct ActiveJvmRuntime {
    child: Option<Child>,
    pid: Option<u32>,
    started_at_secs: u64,
    xmx_mb: u64,
    xms_mb: u64,
    new_gc: bool,
    gc_collections: u64,
    logs: Vec<JvmLogEntry>,
}

impl ActiveJvmRuntime {
    const fn new() -> Self {
        Self {
            child: None,
            pid: None,
            started_at_secs: 0,
            xmx_mb: 3072,
            xms_mb: 512,
            new_gc: true,
            gc_collections: 0,
            logs: Vec::new(),
        }
    }
}

static DOWNLOAD_STATE: Mutex<Option<VersionDownloadStatus>> = Mutex::new(None);
static ACTIVE_JVM: Mutex<ActiveJvmRuntime> = Mutex::new(ActiveJvmRuntime::new());

fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn now_millis() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0)
}

fn format_clock_hms() -> String {
    let secs = now_secs() % 86400;
    let h = secs / 3600;
    let m = (secs % 3600) / 60;
    let s = secs % 60;
    format!("{:02}:{:02}:{:02}", h, m, s)
}

fn push_jvm_log(level: &str, thread: &str, message: String) {
    if let Ok(mut guard) = ACTIVE_JVM.lock() {
        let entry = JvmLogEntry {
            id: format!("{}-{}", now_millis(), guard.logs.len()),
            time: format_clock_hms(),
            level: level.to_string(),
            thread: thread.to_string(),
            message,
        };
        guard.logs.push(entry);
        if guard.logs.len() > 140 {
            let excess = guard.logs.len() - 140;
            guard.logs.drain(0..excess);
        }
    }
}

fn app_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let dir = app.path().app_config_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir)
}

fn config_file_path(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    Ok(app_dir(app)?.join("launcher_config.json"))
}

fn extras_file_path(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    Ok(app_dir(app)?.join("launcher_extras.json"))
}

fn history_file_path(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    Ok(app_dir(app)?.join("launch_history.json"))
}

fn default_mc_dir() -> PathBuf {
    if cfg!(windows) {
        if let Ok(appdata) = std::env::var("APPDATA") {
            return PathBuf::from(appdata).join(".minecraft");
        }
        PathBuf::from(r"C:\Users\Player\AppData\Roaming\.minecraft")
    } else if cfg!(target_os = "macos") {
        let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".into());
        PathBuf::from(home)
            .join("Library")
            .join("Application Support")
            .join("minecraft")
    } else {
        let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".into());
        PathBuf::from(home).join(".minecraft")
    }
}

fn resolve_java_bin(java_path: &str) -> PathBuf {
    if cfg!(windows) {
        let javaw = PathBuf::from(java_path).join("bin").join("javaw.exe");
        if javaw.exists() {
            return javaw;
        }
        let java_exe = PathBuf::from(java_path).join("bin").join("java.exe");
        if java_exe.exists() {
            return java_exe;
        }
        javaw
    } else {
        PathBuf::from(java_path).join("bin").join("java")
    }
}

fn resolve_java_cli_bin(java_path: &str) -> PathBuf {
    if cfg!(windows) {
        PathBuf::from(java_path).join("bin").join("java.exe")
    } else {
        PathBuf::from(java_path).join("bin").join("java")
    }
}

fn parse_java_major(java_path: &str) -> Option<u32> {
    let bin = resolve_java_cli_bin(java_path);
    if !bin.exists() {
        return None;
    }
    let output = Command::new(&bin).arg("-version").output().ok()?;
    let text = format!(
        "{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    for line in text.lines() {
        if let Some(q1) = line.find('"') {
            if let Some(q2) = line[q1 + 1..].find('"') {
                let ver = &line[q1 + 1..q1 + 1 + q2];
                if let Some(rest) = ver.strip_prefix("1.") {
                    if let Some(major) = rest.split('.').next().and_then(|s| s.parse::<u32>().ok()) {
                        return Some(major);
                    }
                } else if let Some(major) = ver
                    .split(|c: char| !c.is_ascii_digit())
                    .next()
                    .and_then(|s| s.parse::<u32>().ok())
                {
                    return Some(major);
                }
            }
        }
    }
    None
}

fn managed_java25_dir(mc_path: &str) -> PathBuf {
    PathBuf::from(mc_path).join("runtime").join("java-25")
}

fn detect_java_installations(mc_path: &str) -> Vec<(String, PathBuf, Option<u32>)> {
    let mut candidates: Vec<PathBuf> = Vec::new();
    candidates.push(managed_java25_dir(mc_path));

    if let Ok(jh) = std::env::var("JAVA_HOME") {
        candidates.push(PathBuf::from(jh));
    }

    let search_roots: Vec<PathBuf> = if cfg!(windows) {
        let pf = std::env::var("ProgramFiles").unwrap_or_else(|_| r"C:\Program Files".into());
        vec![
            PathBuf::from(&pf).join("Eclipse Adoptium"),
            PathBuf::from(&pf).join("Java"),
            PathBuf::from(&pf).join("Zulu"),
            PathBuf::from(&pf).join("Microsoft"),
            PathBuf::from(&pf).join("BellSoft"),
            PathBuf::from(&pf).join("AdoptOpenJDK"),
        ]
    } else {
        vec![
            PathBuf::from("/usr/lib/jvm"),
            PathBuf::from("/Library/Java/JavaVirtualMachines"),
        ]
    };

    for root in search_roots {
        if let Ok(entries) = fs::read_dir(&root) {
            for entry in entries.flatten() {
                let p = entry.path();
                if p.is_dir() {
                    let home = p.join("Contents").join("Home");
                    if home.exists() {
                        candidates.push(home);
                    } else {
                        candidates.push(p);
                    }
                }
            }
        }
    }

    let mut seen = HashSet::new();
    let mut found = Vec::new();
    for dir in candidates {
        let key = dir.to_string_lossy().to_string();
        if seen.contains(&key) {
            continue;
        }
        seen.insert(key);
        if resolve_java_bin(&dir.to_string_lossy()).exists() {
            let major = parse_java_major(&dir.to_string_lossy());
            let label = match major {
                Some(m) => format!("Java {} ({})", m, dir.file_name().and_then(|n| n.to_str()).unwrap_or("JRE")),
                None => format!("Java Runtime ({})", dir.file_name().and_then(|n| n.to_str()).unwrap_or("JRE")),
            };
            found.push((label, dir, major));
        }
    }
    found.sort_by(|a, b| b.2.unwrap_or(0).cmp(&a.2.unwrap_or(0)));
    found
}

fn effective_java_path(configured_java: &str, mc_path: &str, require_java25: bool) -> String {
    let managed = managed_java25_dir(mc_path);
    let managed_str = managed.to_string_lossy().to_string();
    let configured_exists = resolve_java_bin(configured_java).exists();
    let configured_major = parse_java_major(configured_java);

    if require_java25 {
        if configured_exists && configured_major.unwrap_or(0) >= 25 {
            return configured_java.to_string();
        }
        if resolve_java_bin(&managed_str).exists() && parse_java_major(&managed_str).unwrap_or(0) >= 25 {
            return managed_str;
        }
        for (_, dir, major) in detect_java_installations(mc_path) {
            if major.unwrap_or(0) >= 25 {
                return dir.to_string_lossy().to_string();
            }
        }
    } else if configured_exists {
        return configured_java.to_string();
    } else {
        let detected = detect_java_installations(mc_path);
        if let Some((_, dir, _)) = detected.first() {
            return dir.to_string_lossy().to_string();
        }
    }

    configured_java.to_string()
}

fn current_os_name() -> &'static str {
    if cfg!(windows) {
        "windows"
    } else if cfg!(target_os = "macos") {
        "osx"
    } else {
        "linux"
    }
}

fn library_allowed_for_os(lib: &Value) -> bool {
    let Some(rules) = lib.get("rules").and_then(|r| r.as_array()) else {
        return true;
    };
    let os = current_os_name();
    let mut allowed = false;
    for rule in rules {
        let action = rule.get("action").and_then(|a| a.as_str()).unwrap_or("disallow");
        let matches = match rule.get("os") {
            Some(os_obj) => os_obj
                .get("name")
                .and_then(|n| n.as_str())
                .map(|n| n == os)
                .unwrap_or(true),
            None => true,
        };
        if matches {
            allowed = action == "allow";
        }
    }
    allowed
}

fn maven_coord_to_rel_path(coord: &str) -> Option<String> {
    let parts: Vec<&str> = coord.trim().split(':').collect();
    if parts.len() < 3 || parts.len() > 4 {
        return None;
    }
    let group = parts[0].replace('.', "/");
    let artifact = parts[1];
    let mut version = parts[2];
    let mut ext = "jar";
    if let Some((v, e)) = parts[2].split_once('@') {
        version = v;
        ext = if e.is_empty() { "jar" } else { e };
    }
    let classifier = parts
        .get(3)
        .map(|c| c.split('@').next().unwrap_or(""))
        .unwrap_or("");
    let file_name = if classifier.is_empty() {
        format!("{}-{}.{}", artifact, version, ext)
    } else {
        format!("{}-{}-{}.{}", artifact, version, classifier, ext)
    };
    Some(format!("{}/{}/{}/{}", group, artifact, version, file_name))
}

fn maven_group_artifact_key(coord: &str) -> Option<String> {
    let mut parts = coord.trim().split(':');
    let group = parts.next()?;
    let artifact = parts.next()?;
    Some(format!("{}:{}", group, artifact))
}

fn build_http_client() -> Result<reqwest::blocking::Client, String> {
    reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(90))
        .user_agent("AgretiumLauncher/1.0.0")
        .build()
        .map_err(|e| format!("Failed to build HTTP client: {}", e))
}

fn download_bytes(client: &reqwest::blocking::Client, url: &str) -> Result<Vec<u8>, String> {
    let resp = client
        .get(url)
        .send()
        .map_err(|e| format!("Network error fetching {}: {}", url, e))?;
    if !resp.status().is_success() {
        return Err(format!("HTTP {} fetching {}", resp.status(), url));
    }
    resp.bytes()
        .map(|b| b.to_vec())
        .map_err(|e| format!("Failed reading bytes from {}: {}", url, e))
}

fn download_to_file_if_missing(
    client: &reqwest::blocking::Client,
    url: &str,
    target: &Path,
) -> Result<(), String> {
    if target.exists() && fs::metadata(target).map(|m| m.len() > 0).unwrap_or(false) {
        return Ok(());
    }
    if let Some(parent) = target.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let bytes = download_bytes(client, url)?;
    let tmp = target.with_extension("part");
    fs::write(&tmp, &bytes).map_err(|e| e.to_string())?;
    fs::rename(&tmp, target).map_err(|e| e.to_string())?;
    Ok(())
}

fn extract_natives_jar(jar_path: &Path, natives_dir: &Path) -> Result<(), String> {
    fs::create_dir_all(natives_dir).map_err(|e| e.to_string())?;
    let file = fs::File::open(jar_path).map_err(|e| e.to_string())?;
    let mut archive = ZipArchive::new(file).map_err(|e| format!("Invalid native jar: {}", e))?;
    for i in 0..archive.len() {
        let mut entry = archive.by_index(i).map_err(|e| e.to_string())?;
        let name = entry.name().to_string();
        if entry.is_dir() || name.starts_with("META-INF/") {
            continue;
        }
        let lower = name.to_lowercase();
        if !(lower.ends_with(".dll") || lower.ends_with(".so") || lower.ends_with(".dylib")) {
            continue;
        }
        if let Some(file_name) = Path::new(&name).file_name() {
            let out_path = natives_dir.join(file_name);
            let mut out_file = fs::File::create(&out_path).map_err(|e| e.to_string())?;
            std::io::copy(&mut entry, &mut out_file).map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

fn install_managed_java25(
    client: &reqwest::blocking::Client,
    mc_path: &str,
) -> Result<PathBuf, String> {
    let target_dir = managed_java25_dir(mc_path);
    if resolve_java_bin(&target_dir.to_string_lossy()).exists()
        && parse_java_major(&target_dir.to_string_lossy()).unwrap_or(0) >= 25
    {
        return Ok(target_dir);
    }

    let os_slug = if cfg!(windows) {
        "windows"
    } else if cfg!(target_os = "macos") {
        "mac"
    } else {
        "linux"
    };
    let ext = if cfg!(windows) { "zip" } else { "tar.gz" };
    if ext != "zip" {
        return Err("Automatic JRE 25 extraction in desktop build targets Windows ZIP archives. Point Java Path to an installed Java 25 JDK.".to_string());
    }

    let url = format!(
        "https://api.adoptium.net/v3/binary/latest/25/ga/{}/x64/jre/hotspot/normal/eclipse",
        os_slug
    );
    let zip_path = PathBuf::from(mc_path).join("runtime").join("java-25-jre.zip");
    if let Some(parent) = zip_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let bytes = download_bytes(client, &url)?;
    fs::write(&zip_path, &bytes).map_err(|e| e.to_string())?;

    if target_dir.exists() {
        let _ = fs::remove_dir_all(&target_dir);
    }
    fs::create_dir_all(&target_dir).map_err(|e| e.to_string())?;

    let file = fs::File::open(&zip_path).map_err(|e| e.to_string())?;
    let mut archive = ZipArchive::new(file).map_err(|e| format!("Invalid Java 25 zip: {}", e))?;
    for i in 0..archive.len() {
        let mut entry = archive.by_index(i).map_err(|e| e.to_string())?;
        let raw_name = entry.name().replace('\\', "/");
        let stripped = match raw_name.split_once('/') {
            Some((_, rest)) if !rest.is_empty() => rest,
            _ => continue,
        };
        if stripped.contains("..") {
            continue;
        }
        let dest = target_dir.join(stripped);
        if entry.is_dir() {
            fs::create_dir_all(&dest).map_err(|e| e.to_string())?;
        } else {
            if let Some(parent) = dest.parent() {
                fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            let mut out = fs::File::create(&dest).map_err(|e| e.to_string())?;
            std::io::copy(&mut entry, &mut out).map_err(|e| e.to_string())?;
        }
    }
    let _ = fs::remove_file(&zip_path);
    Ok(target_dir)
}

fn ensure_mojang_189_json(
    client: &reqwest::blocking::Client,
    mc_path: &str,
) -> Result<Value, String> {
    let json_path = PathBuf::from(mc_path)
        .join("versions")
        .join("1.8.9")
        .join("1.8.9.json");
    if json_path.exists() {
        if let Ok(raw) = fs::read_to_string(&json_path) {
            if let Ok(parsed) = serde_json::from_str::<Value>(&raw) {
                return Ok(parsed);
            }
        }
    }

    let version_url = match download_bytes(client, MOJANG_MANIFEST_URL)
        .ok()
        .and_then(|b| serde_json::from_slice::<Value>(&b).ok())
        .and_then(|manifest| {
            manifest
                .get("versions")
                .and_then(|v| v.as_array())
                .and_then(|arr| {
                    arr.iter()
                        .find(|entry| entry.get("id").and_then(|id| id.as_str()) == Some("1.8.9"))
                })
                .and_then(|entry| entry.get("url").and_then(|u| u.as_str()))
                .map(|s| s.to_string())
        }) {
        Some(u) => u,
        None => MOJANG_189_FALLBACK_URL.to_string(),
    };

    let bytes = download_bytes(client, &version_url)?;
    let parsed: Value =
        serde_json::from_slice(&bytes).map_err(|e| format!("Invalid 1.8.9.json: {}", e))?;
    if let Some(parent) = json_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(&json_path, &bytes).map_err(|e| e.to_string())?;
    Ok(parsed)
}

fn ensure_ornithe_profile_json(
    client: &reqwest::blocking::Client,
    mc_path: &str,
    loader_version: &str,
) -> Result<Value, String> {
    let profile_path = PathBuf::from(mc_path)
        .join("versions")
        .join("1.8.9-ornithe")
        .join("1.8.9-ornithe.json");
    if profile_path.exists() {
        if let Ok(raw) = fs::read_to_string(&profile_path) {
            if let Ok(parsed) = serde_json::from_str::<Value>(&raw) {
                if parsed.get("libraries").and_then(|l| l.as_array()).is_some() {
                    return Ok(parsed);
                }
            }
        }
    }

    let url = format!(
        "https://meta.ornithemc.net/v3/versions/gen2/fabric-loader/1.8.9/{}/profile/json",
        loader_version
    );
    let bytes = download_bytes(client, &url)?;
    let parsed: Value = serde_json::from_slice(&bytes)
        .map_err(|e| format!("Invalid Ornithe 1.8.9 profile JSON: {}", e))?;
    if let Some(parent) = profile_path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(&profile_path, &bytes).map_err(|e| e.to_string())?;
    Ok(parsed)
}

fn ornithe_loader_jar(mc_path: &str, loader_version: &str) -> PathBuf {
    PathBuf::from(mc_path)
        .join("libraries")
        .join("net")
        .join("fabricmc")
        .join("fabric-loader")
        .join(loader_version)
        .join(format!("fabric-loader-{}.jar", loader_version))
}

fn calamus_jar(mc_path: &str, calamus_version: &str) -> PathBuf {
    PathBuf::from(mc_path)
        .join("libraries")
        .join("net")
        .join("ornithemc")
        .join("calamus-intermediary-gen2")
        .join(calamus_version)
        .join(format!("calamus-intermediary-gen2-{}.jar", calamus_version))
}

fn argentum_jars(mc_path: &str) -> Vec<(&'static str, &'static str, &'static str, PathBuf)> {
    let mods_dir = PathBuf::from(mc_path).join("mods");
    vec![
        (
            "argentum-core",
            "argentum-1.0.2.jar",
            "https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/argentum-1.0.2.jar",
            mods_dir.join("argentum-1.0.2.jar"),
        ),
        (
            "argentum-extras",
            "argentum-extras-1.0.2.jar",
            "https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/argentum-extras-1.0.2.jar",
            mods_dir.join("argentum-extras-1.0.2.jar"),
        ),
        (
            "cera",
            "cera-1.0.2.jar",
            "https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/cera-1.0.2.jar",
            mods_dir.join("cera-1.0.2.jar"),
        ),
        (
            "osl",
            "ornithe-standard-libraries-0.24.0.jar",
            "https://cdn.modrinth.com/data/EHGtwpJv/versions/TzBDamVN/ornithe-standard-libraries-0.24.0.jar",
            mods_dir.join("ornithe-standard-libraries-0.24.0.jar"),
        ),
        (
            "pylon",
            "pylon-0.2.2-beta.1.jar",
            "https://github.com/Polyfrost/pylon/releases/download/0.2.2-beta.1/pylon-0.2.2-beta.1.jar",
            mods_dir.join("pylon-0.2.2-beta.1.jar"),
        ),
        (
            "forgecompat",
            "forgecompat-1.1.4+1.8.9.jar",
            "https://github.com/Polyfrost/ForgeCompat/releases/download/v1.1.4/forgecompat-1.1.4%2B1.8.9.jar",
            mods_dir.join("forgecompat-1.1.4+1.8.9.jar"),
        ),
    ]
}

fn core_argentum_names() -> HashSet<String> {
    [
        "argentum-1.0.2.jar",
        "argentum-extras-1.0.2.jar",
        "cera-1.0.2.jar",
        "ornithe-standard-libraries-0.24.0.jar",
        "pylon-0.2.2-beta.1.jar",
        "forgecompat-1.1.4+1.8.9.jar",
    ]
    .iter()
    .map(|s| s.to_lowercase())
    .collect()
}

fn scan_mod_jars(mc_path: &str) -> Vec<ModJarFile> {
    let mods_dir = PathBuf::from(mc_path).join("mods");
    let _ = fs::create_dir_all(&mods_dir);
    let core_set = core_argentum_names();
    let mut items = Vec::new();
    if let Ok(entries) = fs::read_dir(&mods_dir) {
        for entry in entries.flatten() {
            let p = entry.path();
            if !p.is_file() {
                continue;
            }
            let Some(file_name) = p.file_name().and_then(|n| n.to_str()).map(|s| s.to_string()) else {
                continue;
            };
            let lower = file_name.to_lowercase();
            let is_disabled = lower.ends_with(".jar.disabled");
            let is_enabled = !is_disabled && lower.ends_with(".jar");
            if !is_disabled && !is_enabled {
                continue;
            }
            let base_name = if is_disabled {
                file_name[..file_name.len() - ".disabled".len()].to_string()
            } else {
                file_name.clone()
            };
            let display_name = base_name[..base_name.len() - ".jar".len()].to_string();
            let size_bytes = fs::metadata(&p).map(|m| m.len()).unwrap_or(0);
            let is_core = core_set.contains(&base_name.to_lowercase());
            items.push(ModJarFile {
                file_name,
                base_name,
                display_name,
                enabled: is_enabled,
                size_bytes,
                is_core_argentum: is_core,
            });
        }
    }
    items.sort_by(|a, b| {
        b.is_core_argentum
            .cmp(&a.is_core_argentum)
            .then_with(|| a.base_name.to_lowercase().cmp(&b.base_name.to_lowercase()))
    });
    items
}

fn generate_offline_uuid(username: &str) -> String {
    let mut h1: u32 = 0x811c9dc5;
    let mut h2: u32 = 0xdeadbeef;
    for (i, byte) in username.bytes().enumerate() {
        let code = byte as u32;
        h1 = (h1 ^ code).wrapping_mul(0x01000193);
        h2 = (h2 ^ (code + i as u32)).wrapping_mul(0x85ebca6b);
    }
    format!(
        "{:08x}{:04x}3{:03x}8{:03x}{:08x}{:04x}",
        h1,
        (h2 >> 16) & 0xffff,
        h2 & 0x0fff,
        (h1 ^ h2) & 0x0fff,
        h1,
        h2 & 0xffff
    )
}

fn has_natives_files(mc_path: &str) -> bool {
    let natives_dir = PathBuf::from(mc_path)
        .join("versions")
        .join("1.8.9")
        .join("natives");
    if let Ok(entries) = fs::read_dir(&natives_dir) {
        for entry in entries.flatten() {
            let name = entry.file_name().to_string_lossy().to_lowercase();
            if name.ends_with(".dll") || name.ends_with(".so") || name.ends_with(".dylib") {
                return true;
            }
        }
    }
    false
}

fn update_download_state(status: VersionDownloadStatus) {
    if let Ok(mut guard) = DOWNLOAD_STATE.lock() {
        *guard = Some(status);
    }
}

fn read_history_list(app: &tauri::AppHandle) -> Vec<LaunchHistoryEntry> {
    let Ok(path) = history_file_path(app) else {
        return Vec::new();
    };
    if !path.exists() {
        return Vec::new();
    }
    fs::read_to_string(path)
        .ok()
        .and_then(|raw| serde_json::from_str(&raw).ok())
        .unwrap_or_default()
}

fn append_history_entry(app: &tauri::AppHandle, entry: LaunchHistoryEntry) {
    let Ok(path) = history_file_path(app) else {
        return;
    };
    let mut list = read_history_list(app);
    list.insert(0, entry);
    list.truncate(20);
    if let Ok(json) = serde_json::to_string_pretty(&list) {
        let _ = fs::write(path, json);
    }
}

#[tauri::command]
fn get_system_info() -> SystemInfo {
    let mut sys = System::new_all();
    sys.refresh_memory();
    let total_ram_mb = (sys.total_memory() / (1024 * 1024)).max(4096);
    SystemInfo { total_ram_mb }
}

#[tauri::command]
fn get_default_paths(app: tauri::AppHandle) -> DefaultPaths {
    let mc_dir = default_mc_dir();
    let mc_str = mc_dir.to_string_lossy().to_string();
    let detected = detect_java_installations(&mc_str);
    let java_str = detected
        .iter()
        .find(|(_, _, major)| major.unwrap_or(0) >= 25)
        .or_else(|| detected.first())
        .map(|(_, p, _)| p.to_string_lossy().to_string())
        .unwrap_or_else(|| managed_java25_dir(&mc_str).to_string_lossy().to_string());
    let cfg_path = config_file_path(&app)
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|_| "launcher_config.json".into());
    DefaultPaths {
        mc_path: mc_str,
        java_path: java_str,
        config_path: cfg_path,
    }
}

#[tauri::command]
fn load_settings(app: tauri::AppHandle) -> Result<Option<LauncherSettings>, String> {
    let path = config_file_path(&app)?;
    if !path.exists() {
        return Ok(None);
    }
    let raw = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let parsed: LauncherSettings = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    Ok(Some(parsed))
}

#[tauri::command]
fn save_settings(app: tauri::AppHandle, settings: LauncherSettings) -> Result<(), String> {
    let path = config_file_path(&app)?;
    let json = serde_json::to_string_pretty(&settings).map_err(|e| e.to_string())?;
    fs::write(path, json).map_err(|e| e.to_string())
}

#[tauri::command]
fn load_extras(app: tauri::AppHandle) -> Result<Option<Value>, String> {
    let path = extras_file_path(&app)?;
    if !path.exists() {
        return Ok(None);
    }
    let raw = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let parsed: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    Ok(Some(parsed))
}

#[tauri::command]
fn save_extras(app: tauri::AppHandle, extras: Value) -> Result<(), String> {
    let path = extras_file_path(&app)?;
    let json = serde_json::to_string_pretty(&extras).map_err(|e| e.to_string())?;
    fs::write(path, json).map_err(|e| e.to_string())
}

#[tauri::command]
fn load_launch_history(app: tauri::AppHandle) -> Vec<LaunchHistoryEntry> {
    read_history_list(&app)
}

#[tauri::command]
async fn pick_folder() -> Option<String> {
    let folder = rfd::AsyncFileDialog::new().pick_folder().await?;
    Some(folder.path().to_string_lossy().to_string())
}

#[tauri::command]
fn list_directory(dir_path: Option<String>, mc_path: Option<String>) -> Result<DirectoryListing, String> {
    let default_mc = mc_path
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| default_mc_dir().to_string_lossy().to_string());
    let target = match dir_path.filter(|s| !s.trim().is_empty()) {
        Some(p) => PathBuf::from(p),
        None => PathBuf::from(&default_mc),
    };
    let resolved = if target.exists() && target.is_dir() {
        target
    } else {
        std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."))
    };

    let mut presets = vec![DirectoryPreset {
        label: "Minecraft Home (.minecraft)".into(),
        path: default_mc.clone(),
        description: "Standard Minecraft 1.8.9 game & mods directory".into(),
    }];
    for (label, path, _) in detect_java_installations(&default_mc).into_iter().take(3) {
        presets.push(DirectoryPreset {
            label,
            path: path.to_string_lossy().to_string(),
            description: "Detected Java Runtime".into(),
        });
    }

    let mut entries = Vec::new();
    let dir_iter = fs::read_dir(&resolved).map_err(|e| e.to_string())?;
    for item in dir_iter.flatten() {
        let p = item.path();
        if !p.is_dir() {
            continue;
        }
        let name = item.file_name().to_string_lossy().to_string();
        if name.starts_with('.') && name != ".minecraft" {
            continue;
        }
        let hint = if resolve_java_bin(&p.to_string_lossy()).exists() {
            Some("Java Runtime".into())
        } else if p.join("versions").exists() || p.join("mods").exists() {
            Some("Minecraft Directory".into())
        } else {
            None
        };
        entries.push(DirectoryEntry {
            name,
            path: p.to_string_lossy().to_string(),
            is_directory: true,
            hint,
        });
    }
    entries.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    entries.truncate(80);

    let parent_path = resolved.parent().map(|p| p.to_string_lossy().to_string());
    Ok(DirectoryListing {
        current_path: resolved.to_string_lossy().to_string(),
        parent_path,
        entries,
        presets,
    })
}

#[tauri::command]
fn list_mod_jars(mc_path: String) -> Vec<ModJarFile> {
    scan_mod_jars(&mc_path)
}

#[tauri::command]
async fn add_mod_jars(mc_path: String) -> Result<Vec<ModJarFile>, String> {
    let files = rfd::AsyncFileDialog::new()
        .add_filter("Minecraft Mod JAR", &["jar"])
        .pick_files()
        .await;
    let Some(selected) = files else {
        return Ok(scan_mod_jars(&mc_path));
    };

    let mods_dir = PathBuf::from(&mc_path).join("mods");
    fs::create_dir_all(&mods_dir).map_err(|e| e.to_string())?;

    for file in selected {
        let src = file.path();
        let Some(fname) = src.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        if !fname.to_lowercase().ends_with(".jar") {
            continue;
        }
        let dest = mods_dir.join(fname);
        fs::copy(src, &dest).map_err(|e| format!("Failed copying {}: {}", fname, e))?;
    }
    Ok(scan_mod_jars(&mc_path))
}

#[tauri::command]
fn toggle_mod_jar(mc_path: String, file_name: String, enabled: bool) -> Result<Vec<ModJarFile>, String> {
    let mods_dir = PathBuf::from(&mc_path).join("mods");
    let clean_name = Path::new(&file_name)
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| "Invalid mod filename".to_string())?;
    let src = mods_dir.join(clean_name);
    if !src.exists() {
        return Err(format!("Mod file not found: {}", clean_name));
    }
    let base = clean_name
        .strip_suffix(".disabled")
        .unwrap_or(clean_name);
    let next_name = if enabled {
        base.to_string()
    } else {
        format!("{}.disabled", base)
    };
    let dest = mods_dir.join(next_name);
    if src != dest {
        fs::rename(&src, &dest).map_err(|e| e.to_string())?;
    }
    Ok(scan_mod_jars(&mc_path))
}

#[tauri::command]
fn delete_mod_jar(mc_path: String, file_name: String) -> Result<Vec<ModJarFile>, String> {
    let mods_dir = PathBuf::from(&mc_path).join("mods");
    let clean_name = Path::new(&file_name)
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| "Invalid mod filename".to_string())?;
    let target = mods_dir.join(clean_name);
    if target.exists() {
        fs::remove_file(&target).map_err(|e| e.to_string())?;
    }
    Ok(scan_mod_jars(&mc_path))
}

#[tauri::command]
fn open_mods_folder(mc_path: String) -> Result<(), String> {
    let mods_dir = PathBuf::from(&mc_path).join("mods");
    fs::create_dir_all(&mods_dir).map_err(|e| e.to_string())?;
    if cfg!(windows) {
        Command::new("explorer").arg(&mods_dir).spawn().map_err(|e| e.to_string())?;
    } else if cfg!(target_os = "macos") {
        Command::new("open").arg(&mods_dir).spawn().map_err(|e| e.to_string())?;
    } else {
        Command::new("xdg-open").arg(&mods_dir).spawn().map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn check_ornithe_preflight(
    mc_path: String,
    java_path: String,
    ornithe_enabled: bool,
    agretium_enabled: bool,
) -> PreflightStatus {
    let cfg = OrnitheConfig::default();
    let eff_java = effective_java_path(&java_path, &mc_path, agretium_enabled);
    let java_bin = resolve_java_bin(&eff_java);
    let java_major = parse_java_major(&eff_java).unwrap_or(0);
    let client_jar = PathBuf::from(&mc_path)
        .join("versions")
        .join("1.8.9")
        .join("1.8.9.jar");
    let client_json = PathBuf::from(&mc_path)
        .join("versions")
        .join("1.8.9")
        .join("1.8.9.json");
    let assets_index = PathBuf::from(&mc_path)
        .join("assets")
        .join("indexes")
        .join("1.8.json");
    let loader = ornithe_loader_jar(&mc_path, &cfg.loader_version);
    let calamus = calamus_jar(&mc_path, &cfg.calamus_version);
    let profile = PathBuf::from(&mc_path)
        .join("versions")
        .join("1.8.9-ornithe")
        .join("1.8.9-ornithe.json");

    let java_ok = java_bin.exists() && (!agretium_enabled || java_major >= 25);
    let jar_ok = client_jar.exists() && client_json.exists() && has_natives_files(&mc_path);
    let assets_ok = assets_index.exists();
    let ornithe_ok = !ornithe_enabled || (loader.exists() && calamus.exists() && profile.exists());
    let arg_missing: Vec<_> = argentum_jars(&mc_path)
        .into_iter()
        .filter(|(_, _, _, p)| !p.exists())
        .collect();
    let argentum_ok = !agretium_enabled || arg_missing.is_empty();

    let mut missing_artifacts = Vec::new();
    if !java_ok {
        missing_artifacts.push(if agretium_enabled {
            "Eclipse Temurin Java 25 Runtime (Required for Argentum/ForgeCompat)".to_string()
        } else {
            "Java Runtime".to_string()
        });
    }
    if !client_jar.exists() || !client_json.exists() {
        missing_artifacts.push("Minecraft 1.8.9 Client JAR & Manifest".to_string());
    }
    if !has_natives_files(&mc_path) {
        missing_artifacts.push("Minecraft 1.8.9 Libraries & LWJGL Natives".to_string());
    }
    if !assets_ok {
        missing_artifacts.push("1.8 Asset Index & Sound Resources".to_string());
    }
    if ornithe_enabled {
        if !loader.exists() {
            missing_artifacts.push(format!("Ornithe Fabric Loader {}", cfg.loader_version));
        }
        if !calamus.exists() {
            missing_artifacts.push(format!("Ornithe Calamus Gen2 Mappings {}", cfg.calamus_version));
        }
        if !profile.exists() {
            missing_artifacts.push("1.8.9-ornithe Launch Profile".to_string());
        }
    }
    if agretium_enabled {
        for (_, fname, _, _) in arg_missing {
            missing_artifacts.push(fname.to_string());
        }
    }

    PreflightStatus {
        java_ok,
        jar_ok,
        assets_ok,
        ornithe_ok,
        argentum_ok,
        needs_download: !missing_artifacts.is_empty(),
        missing_artifacts,
        java_bin: java_bin.to_string_lossy().to_string(),
        client_jar: client_jar.to_string_lossy().to_string(),
        checked_at: "desktop".to_string(),
    }
}

#[tauri::command]
fn download_ornithe_and_mods(
    mc_path: String,
    ornithe: OrnitheConfig,
    include_argentum: bool,
) -> Result<VersionDownloadStatus, String> {
    let mut initial_artifacts = vec![
        DownloadArtifact {
            id: "mc-189-jar".into(),
            label: "Minecraft 1.8.9 Client, Libraries & Natives".into(),
            file_name: "1.8.9.jar".into(),
            size_label: "22 MB".into(),
            status: "downloading".into(),
            group: "client".into(),
        },
        DownloadArtifact {
            id: "mc-18-assets".into(),
            label: "Minecraft 1.8 Asset Index & Sounds".into(),
            file_name: "1.8.json".into(),
            size_label: "114 MB".into(),
            status: "pending".into(),
            group: "client".into(),
        },
    ];

    if ornithe.enabled {
        initial_artifacts.push(DownloadArtifact {
            id: "ornithe-loader".into(),
            label: format!("Ornithe Gen2 Loader {} & Libraries", ornithe.loader_version),
            file_name: format!("fabric-loader-{}.jar", ornithe.loader_version),
            size_label: "4.5 MB".into(),
            status: "pending".into(),
            group: "ornithe".into(),
        });
    }

    if include_argentum {
        initial_artifacts.push(DownloadArtifact {
            id: "java-25".into(),
            label: "Eclipse Temurin Java 25 JRE".into(),
            file_name: "java-25".into(),
            size_label: "48 MB".into(),
            status: "pending".into(),
            group: "client".into(),
        });
        for (id, fname, _, _) in argentum_jars(&mc_path) {
            initial_artifacts.push(DownloadArtifact {
                id: id.into(),
                label: fname.into(),
                file_name: fname.into(),
                size_label: "JAR".into(),
                status: "pending".into(),
                group: "argentum".into(),
            });
        }
    }

    let total = initial_artifacts.len();
    let initial = VersionDownloadStatus {
        state: "downloading".into(),
        percent: 5,
        current_artifact: Some(initial_artifacts[0].label.clone()),
        completed_count: 0,
        total_count: total,
        artifacts: initial_artifacts.clone(),
        error: None,
    };
    update_download_state(initial.clone());

    std::thread::spawn(move || {
        let mut artifacts = initial_artifacts;
        let mark_step = |artifacts: &mut Vec<DownloadArtifact>, id: &str, status: &str, active_label: Option<&str>| {
            for a in artifacts.iter_mut() {
                if a.id == id {
                    a.status = status.into();
                }
            }
            let done = artifacts.iter().filter(|a| a.status == "done").count();
            let pct = ((done * 100) / artifacts.len().max(1)).max(5) as u8;
            let snap = VersionDownloadStatus {
                state: if done >= artifacts.len() { "complete".into() } else { "downloading".into() },
                percent: if done >= artifacts.len() { 100 } else { pct },
                current_artifact: active_label.map(|s| s.to_string()),
                completed_count: done,
                total_count: artifacts.len(),
                artifacts: artifacts.clone(),
                error: None,
            };
            update_download_state(snap);
        };

        let result: Result<(), String> = (|| {
            let client = build_http_client()?;

            // 1. Mojang 1.8.9 JSON + Client JAR + Libraries + Natives
            let v189 = ensure_mojang_189_json(&client, &mc_path)?;
            let client_url = v189
                .pointer("/downloads/client/url")
                .and_then(|u| u.as_str())
                .unwrap_or("https://piston-data.mojang.com/v1/objects/3870888a6c3d349d3771a3e9d16c9bf5e076b908/client.jar");
            let client_jar = PathBuf::from(&mc_path)
                .join("versions")
                .join("1.8.9")
                .join("1.8.9.jar");
            download_to_file_if_missing(&client, client_url, &client_jar)?;

            let natives_dir = PathBuf::from(&mc_path)
                .join("versions")
                .join("1.8.9")
                .join("natives");
            let os = current_os_name();
            if let Some(libs) = v189.get("libraries").and_then(|l| l.as_array()) {
                for lib in libs {
                    if !library_allowed_for_os(lib) {
                        continue;
                    }
                    if let Some(artifact) = lib.pointer("/downloads/artifact") {
                        if let (Some(url), Some(rel_path)) = (
                            artifact.get("url").and_then(|u| u.as_str()),
                            artifact.get("path").and_then(|p| p.as_str()),
                        ) {
                            let target = PathBuf::from(&mc_path).join("libraries").join(rel_path);
                            download_to_file_if_missing(&client, url, &target)?;
                        }
                    }
                    if let Some(native_key) = lib.pointer(&format!("/natives/{}", os)).and_then(|v| v.as_str()) {
                        let key_resolved = native_key.replace("${arch}", if cfg!(target_pointer_width = "64") { "64" } else { "32" });
                        if let Some(classifier) = lib.pointer(&format!("/downloads/classifiers/{}", key_resolved)) {
                            if let (Some(url), Some(rel_path)) = (
                                classifier.get("url").and_then(|u| u.as_str()),
                                classifier.get("path").and_then(|p| p.as_str()),
                            ) {
                                let target = PathBuf::from(&mc_path).join("libraries").join(rel_path);
                                download_to_file_if_missing(&client, url, &target)?;
                                extract_natives_jar(&target, &natives_dir)?;
                            }
                        }
                    }
                }
            }
            mark_step(&mut artifacts, "mc-189-jar", "done", Some("Minecraft 1.8 Asset Index & Sounds"));

            // 2. Asset Index & Objects
            mark_step(&mut artifacts, "mc-18-assets", "downloading", Some("Minecraft 1.8 Asset Index & Sounds"));
            let asset_url = v189
                .pointer("/assetIndex/url")
                .and_then(|u| u.as_str())
                .unwrap_or("https://launchermeta.mojang.com/v1/packages/f6ad102bcaa53b1a58358f16e376d548d44933ec/1.8.json");
            let asset_index_path = PathBuf::from(&mc_path)
                .join("assets")
                .join("indexes")
                .join("1.8.json");
            download_to_file_if_missing(&client, asset_url, &asset_index_path)?;
            if let Ok(raw_idx) = fs::read_to_string(&asset_index_path) {
                if let Ok(idx_json) = serde_json::from_str::<Value>(&raw_idx) {
                    if let Some(objects) = idx_json.get("objects").and_then(|o| o.as_object()) {
                        let mut missing_objects: Vec<(String, PathBuf)> = Vec::new();
                        for (_, obj) in objects {
                            if let Some(hash) = obj.get("hash").and_then(|h| h.as_str()) {
                                if hash.len() >= 2 {
                                    let prefix = &hash[0..2];
                                    let target = PathBuf::from(&mc_path)
                                        .join("assets")
                                        .join("objects")
                                        .join(prefix)
                                        .join(hash);
                                    if !target.exists() {
                                        let url = format!("https://resources.download.minecraft.net/{}/{}", prefix, hash);
                                        missing_objects.push((url, target));
                                    }
                                }
                            }
                        }
                        if !missing_objects.is_empty() {
                            let queue = Arc::new(Mutex::new(missing_objects));
                            std::thread::scope(|s| {
                                for _ in 0..8 {
                                    let q = Arc::clone(&queue);
                                    let c = &client;
                                    s.spawn(move || loop {
                                        let next = q.lock().ok().and_then(|mut g| g.pop());
                                        let Some((url, target)) = next else { break };
                                        let _ = download_to_file_if_missing(c, &url, &target);
                                    });
                                }
                            });
                        }
                    }
                }
            }
            mark_step(&mut artifacts, "mc-18-assets", "done", None);

            // 3. Ornithe Gen2 Profile & All Maven Libraries
            if ornithe.enabled {
                mark_step(
                    &mut artifacts,
                    "ornithe-loader",
                    "downloading",
                    Some(&format!("Ornithe Gen2 Loader {} & Libraries", ornithe.loader_version)),
                );
                let ornithe_json = ensure_ornithe_profile_json(&client, &mc_path, &ornithe.loader_version)?;
                if let Some(libs) = ornithe_json.get("libraries").and_then(|l| l.as_array()) {
                    for lib in libs {
                        let Some(coord) = lib.get("name").and_then(|n| n.as_str()) else {
                            continue;
                        };
                        let Some(rel_path) = maven_coord_to_rel_path(coord) else {
                            continue;
                        };
                        let base_url = lib
                            .get("url")
                            .and_then(|u| u.as_str())
                            .unwrap_or("https://maven.fabricmc.net/");
                        let full_url = format!("{}{}", base_url.trim_end_matches('/'), format!("/{}", rel_path));
                        let target = PathBuf::from(&mc_path).join("libraries").join(&rel_path);
                        download_to_file_if_missing(&client, &full_url, &target)?;
                    }
                }
                mark_step(&mut artifacts, "ornithe-loader", "done", None);
            }

            // 4. Java 25 JRE + Argentum / OSL / Pylon / ForgeCompat JARs
            if include_argentum {
                mark_step(&mut artifacts, "java-25", "downloading", Some("Eclipse Temurin Java 25 JRE"));
                let has_any_java25 = detect_java_installations(&mc_path)
                    .iter()
                    .any(|(_, _, major)| major.unwrap_or(0) >= 25);
                if !has_any_java25 {
                    install_managed_java25(&client, &mc_path)?;
                }
                mark_step(&mut artifacts, "java-25", "done", None);

                for (id, fname, url, path) in argentum_jars(&mc_path) {
                    mark_step(&mut artifacts, id, "downloading", Some(fname));
                    download_to_file_if_missing(&client, url, &path)?;
                    mark_step(&mut artifacts, id, "done", None);
                }
            }

            Ok(())
        })();

        if let Err(err) = result {
            let done = artifacts.iter().filter(|a| a.status == "done").count();
            update_download_state(VersionDownloadStatus {
                state: "error".into(),
                percent: ((done * 100) / artifacts.len().max(1)) as u8,
                current_artifact: None,
                completed_count: done,
                total_count: artifacts.len(),
                artifacts,
                error: Some(err),
            });
        }
    });

    Ok(initial)
}

#[tauri::command]
fn get_download_status() -> VersionDownloadStatus {
    DOWNLOAD_STATE
        .lock()
        .ok()
        .and_then(|g| g.clone())
        .unwrap_or(VersionDownloadStatus {
            state: "idle".into(),
            percent: 0,
            current_artifact: None,
            completed_count: 0,
            total_count: 0,
            artifacts: vec![],
            error: None,
        })
}

#[tauri::command]
fn reset_version_cache(mc_path: String) -> PreflightStatus {
    let base = PathBuf::from(&mc_path);
    let _ = fs::remove_dir_all(base.join("versions").join("1.8.9"));
    let _ = fs::remove_dir_all(base.join("versions").join("1.8.9-ornithe"));
    let _ = fs::remove_dir_all(base.join("libraries"));
    let _ = fs::remove_file(base.join("assets").join("indexes").join("1.8.json"));
    for (_, _, _, p) in argentum_jars(&mc_path) {
        let _ = fs::remove_file(p);
    }
    if let Ok(mut guard) = DOWNLOAD_STATE.lock() {
        *guard = None;
    }
    check_ornithe_preflight(mc_path, String::new(), true, true)
}

fn build_desktop_classpath(mc_path: &str, ornithe_enabled: bool, loader_version: &str) -> Result<(String, Option<String>), String> {
    let sep = if cfg!(windows) { ";" } else { ":" };
    let mut seen_ga = HashSet::new();
    let mut entries: Vec<String> = Vec::new();
    let mut ornithe_main_class: Option<String> = None;

    if ornithe_enabled {
        let profile_path = PathBuf::from(mc_path)
            .join("versions")
            .join("1.8.9-ornithe")
            .join("1.8.9-ornithe.json");
        if profile_path.exists() {
            if let Ok(raw) = fs::read_to_string(&profile_path) {
                if let Ok(json) = serde_json::from_str::<Value>(&raw) {
                    ornithe_main_class = json
                        .get("mainClass")
                        .and_then(|m| m.as_str())
                        .map(|s| s.to_string());
                    if let Some(libs) = json.get("libraries").and_then(|l| l.as_array()) {
                        for lib in libs {
                            if let Some(coord) = lib.get("name").and_then(|n| n.as_str()) {
                                if let Some(rel) = maven_coord_to_rel_path(coord) {
                                    let jar = PathBuf::from(mc_path).join("libraries").join(rel);
                                    if jar.exists() {
                                        if let Some(ga) = maven_group_artifact_key(coord) {
                                            seen_ga.insert(ga);
                                        }
                                        entries.push(jar.to_string_lossy().to_string());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if entries.is_empty() {
            let loader = ornithe_loader_jar(mc_path, loader_version);
            let calamus = calamus_jar(mc_path, "1.8.9");
            if loader.exists() {
                entries.push(loader.to_string_lossy().to_string());
            }
            if calamus.exists() {
                entries.push(calamus.to_string_lossy().to_string());
            }
        }
    }

    let v189_path = PathBuf::from(mc_path)
        .join("versions")
        .join("1.8.9")
        .join("1.8.9.json");
    if v189_path.exists() {
        if let Ok(raw) = fs::read_to_string(&v189_path) {
            if let Ok(json) = serde_json::from_str::<Value>(&raw) {
                if let Some(libs) = json.get("libraries").and_then(|l| l.as_array()) {
                    for lib in libs {
                        if !library_allowed_for_os(lib) {
                            continue;
                        }
                        if lib.get("natives").is_some() && lib.pointer("/downloads/artifact").is_none() {
                            continue;
                        }
                        if let Some(coord) = lib.get("name").and_then(|n| n.as_str()) {
                            if let Some(ga) = maven_group_artifact_key(coord) {
                                if seen_ga.contains(&ga) {
                                    continue;
                                }
                                seen_ga.insert(ga);
                            }
                        }
                        if let Some(rel) = lib.pointer("/downloads/artifact/path").and_then(|p| p.as_str()) {
                            let jar = PathBuf::from(mc_path).join("libraries").join(rel);
                            if jar.exists() {
                                entries.push(jar.to_string_lossy().to_string());
                            }
                        }
                    }
                }
            }
        }
    }

    let client_jar = PathBuf::from(mc_path)
        .join("versions")
        .join("1.8.9")
        .join("1.8.9.jar");
    entries.push(client_jar.to_string_lossy().to_string());

    Ok((entries.join(sep), ornithe_main_class))
}

#[tauri::command]
fn launch_minecraft(
    app: tauri::AppHandle,
    settings: LauncherSettings,
    ornithe: Option<OrnitheConfig>,
    server_address: Option<String>,
    enabled_mods: Option<Vec<String>>,
) -> Result<LaunchResponse, String> {
    let _ = save_settings(app.clone(), settings.clone());
    let ornithe_cfg = ornithe.unwrap_or_default();
    let eff_java = effective_java_path(&settings.java_path, &settings.mc_path, settings.optifine);
    let java_bin = resolve_java_bin(&eff_java);
    if !java_bin.exists() {
        return Err(format!("Java executable not found at: {}", java_bin.display()));
    }

    if settings.optifine {
        let major = parse_java_major(&eff_java).unwrap_or(0);
        if major > 0 && major < 25 {
            return Err(format!(
                "Argentum 1.0.2 & ForgeCompat require Java 25, but detected Java {}. Click Download Now or point Java Path to JDK/JRE 25.",
                major
            ));
        }
    }

    let client_jar = PathBuf::from(&settings.mc_path)
        .join("versions")
        .join("1.8.9")
        .join("1.8.9.jar");
    if !client_jar.exists() {
        return Err(format!("Minecraft 1.8.9 jar not found at: {}", client_jar.display()));
    }

    let mods_dir = PathBuf::from(&settings.mc_path).join("mods");
    fs::create_dir_all(&mods_dir).map_err(|e| e.to_string())?;
    if let Some(ref mods_list) = enabled_mods {
        let cfg_dir = PathBuf::from(&settings.mc_path).join("config");
        let _ = fs::create_dir_all(&cfg_dir);
        if let Ok(json) = serde_json::to_string_pretty(mods_list) {
            let _ = fs::write(cfg_dir.join("agretium-modules.json"), json);
        }
    }

    let active_jars: Vec<String> = scan_mod_jars(&settings.mc_path)
        .into_iter()
        .filter(|m| m.enabled)
        .map(|m| m.file_name)
        .collect();

    let (classpath, ornithe_main) =
        build_desktop_classpath(&settings.mc_path, ornithe_cfg.enabled, &ornithe_cfg.loader_version)?;

    let natives_dir = PathBuf::from(&settings.mc_path)
        .join("versions")
        .join("1.8.9")
        .join("natives");
    let assets_dir = PathBuf::from(&settings.mc_path).join("assets");

    let (res_w, res_h) = settings
        .resolution
        .split_once('x')
        .or_else(|| settings.resolution.split_once('X'))
        .and_then(|(w, h)| Some((w.trim().to_string(), h.trim().to_string())))
        .unwrap_or_else(|| ("1280".to_string(), "720".to_string()));

    let mut args: Vec<String> = vec![
        format!("-Xmx{}M", settings.ram_mb.max(1024)),
        "-Xms512M".into(),
    ];
    if settings.new_gc {
        args.push("-XX:+UseG1GC".into());
    }
    args.extend([
        "-XX:+ParallelRefProcEnabled".into(),
        "-XX:MaxGCPauseMillis=50".into(),
        "-XX:+DisableExplicitGC".into(),
        "-Djava.net.preferIPv4Stack=true".into(),
        format!("-Djava.library.path={}", natives_dir.display()),
    ]);
    if cfg!(target_os = "macos") {
        args.push("-XstartOnFirstThread".into());
    }

    if ornithe_cfg.enabled {
        let main_class = ornithe_main
            .unwrap_or_else(|| "net.fabricmc.loader.impl.launch.knot.KnotClient".to_string());
        args.extend([
            "-Dfabric.fixPackageAccess=true".into(),
            "-Dfabric.gameVersion=1.8.9".into(),
            format!("-Dfabric.loaderVersion={}", ornithe_cfg.loader_version),
            format!("-Dornithe.mappings=calamus-gen2-{}", ornithe_cfg.calamus_version),
            "-Dmixin.hotSwap=false".into(),
            "-cp".into(),
            classpath,
            main_class,
        ]);
    } else {
        args.extend([
            "-cp".into(),
            classpath,
            "net.minecraft.client.main.Main".into(),
        ]);
    }

    let uuid = generate_offline_uuid(&settings.account);
    args.extend([
        "--username".into(),
        settings.account.clone(),
        "--version".into(),
        if ornithe_cfg.enabled {
            "1.8.9-ornithe".into()
        } else {
            "1.8.9".into()
        },
        "--gameDir".into(),
        settings.mc_path.clone(),
        "--assetsDir".into(),
        assets_dir.to_string_lossy().to_string(),
        "--assetIndex".into(),
        "1.8".into(),
        "--uuid".into(),
        uuid,
        "--accessToken".into(),
        "0".into(),
        "--userProperties".into(),
        "{}".into(),
        "--userType".into(),
        "legacy".into(),
        "--width".into(),
        res_w,
        "--height".into(),
        res_h,
    ]);

    if let Some(ref srv) = server_address {
        let trimmed = srv.trim();
        if !trimmed.is_empty() {
            let (host, port) = match trimmed.rsplit_once(':') {
                Some((h, p)) if p.parse::<u16>().is_ok() => (h.trim(), p.trim()),
                _ => (trimmed, "25565"),
            };
            args.extend([
                "--server".into(),
                host.to_string(),
                "--port".into(),
                port.to_string(),
            ]);
        }
    }

    let mut cmd = Command::new(&java_bin);
    cmd.args(&args)
        .current_dir(&settings.mc_path)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let mut child = cmd
        .spawn()
        .map_err(|e| format!("Failed to start Java ({}): {}", java_bin.display(), e))?;
    let pid = child.id();

    let stdout = child.stdout.take();
    let stderr = child.stderr.take();

    if let Ok(mut guard) = ACTIVE_JVM.lock() {
        if let Some(mut prev) = guard.child.take() {
            let _ = prev.kill();
        }
        guard.child = Some(child);
        guard.pid = Some(pid);
        guard.started_at_secs = now_secs();
        guard.xmx_mb = settings.ram_mb.max(1024);
        guard.xms_mb = 512;
        guard.new_gc = settings.new_gc;
        guard.gc_collections = 0;
        guard.logs.clear();
    }

    push_jvm_log(
        "INFO",
        "Launcher",
        format!(
            "Spawned {} (PID {}) with {} active mod JARs in {}: {}",
            if ornithe_cfg.enabled { "Ornithe 1.8.9" } else { "Minecraft 1.8.9" },
            pid,
            active_jars.len(),
            mods_dir.display(),
            if active_jars.is_empty() {
                "none".into()
            } else {
                active_jars.join(", ")
            }
        ),
    );

    if let Some(out) = stdout {
        std::thread::spawn(move || {
            for line in BufReader::new(out).lines().map_while(Result::ok) {
                push_jvm_log("INFO", "Game/stdout", line);
            }
        });
    }
    if let Some(err) = stderr {
        std::thread::spawn(move || {
            for line in BufReader::new(err).lines().map_while(Result::ok) {
                push_jvm_log("WARN", "Game/stderr", line);
            }
        });
    }

    if settings.minimize_on_launch {
        if let Some(win) = app.get_webview_window("main") {
            let _ = win.minimize();
        }
    }

    let command_line = format!("{} {}", java_bin.display(), args.join(" "));
    let message = format!(
        "Launched {} ({} MB RAM · {} mod JARs)",
        if ornithe_cfg.enabled { "Ornithe 1.8.9" } else { "Minecraft 1.8.9" },
        settings.ram_mb,
        active_jars.len()
    );
    let history_entry = LaunchHistoryEntry {
        id: format!("{}", now_millis()),
        timestamp: format!("{}", now_secs()),
        version: if ornithe_cfg.enabled {
            "1.8.9-ornithe".into()
        } else {
            "1.8.9".into()
        },
        account: settings.account.clone(),
        ram_mb: settings.ram_mb,
        optifine: settings.optifine,
        resolution: settings.resolution.clone(),
        command: command_line.clone(),
        status: "launched".into(),
        message: message.clone(),
        server_address,
        launch_duration_ms: Some(150),
    };
    append_history_entry(&app, history_entry.clone());

    Ok(LaunchResponse {
        ok: true,
        message,
        command: command_line,
        args,
        java_bin: java_bin.to_string_lossy().to_string(),
        client_jar: client_jar.to_string_lossy().to_string(),
        minimized: settings.minimize_on_launch,
        history_entry,
    })
}

#[tauri::command]
fn get_jvm_status() -> JvmStatusSnapshot {
    let mut sys = System::new_all();
    sys.refresh_memory();
    let host_total_ram_mb = (sys.total_memory() / (1024 * 1024)).max(4096);
    let host_free_ram_mb = (sys.available_memory() / (1024 * 1024)).max(256);

    let mut guard = ACTIVE_JVM.lock().unwrap();
    if let Some(ref mut child) = guard.child {
        if let Ok(Some(exit)) = child.try_wait() {
            let pid_val = guard.pid.take();
            guard.child = None;
            guard.logs.push(JvmLogEntry {
                id: format!("{}-exit", now_millis()),
                time: format_clock_hms(),
                level: if exit.success() { "INFO".into() } else { "WARN".into() },
                thread: "Launcher".into(),
                message: format!(
                    "Minecraft process (PID {}) exited with status {}",
                    pid_val.unwrap_or(0),
                    exit
                ),
            });
        }
    }

    let running = guard.child.is_some();
    let used_mb = if running {
        guard
            .pid
            .and_then(|p| sys.process(Pid::from_u32(p)))
            .map(|proc| (proc.memory() / (1024 * 1024)).min(guard.xmx_mb))
            .unwrap_or(0)
    } else {
        0
    };
    let allocated_mb = if running {
        used_mb.max(guard.xms_mb).min(guard.xmx_mb)
    } else {
        0
    };
    let uptime_seconds = if running {
        now_secs().saturating_sub(guard.started_at_secs)
    } else {
        0
    };

    JvmStatusSnapshot {
        running,
        pid: guard.pid,
        version: "1.8.9".into(),
        xmx_mb: guard.xmx_mb,
        xms_mb: guard.xms_mb,
        allocated_mb,
        used_mb,
        gc_algorithm: if guard.new_gc {
            "G1GC (-XX:+UseG1GC)".into()
        } else {
            "Parallel GC (Default)".into()
        },
        xmx_flag: format!("-Xmx{}M", guard.xmx_mb),
        xmx_verified: allocated_mb <= guard.xmx_mb && used_mb <= guard.xmx_mb,
        host_total_ram_mb,
        host_free_ram_mb,
        uptime_seconds,
        gc_collections: guard.gc_collections,
        timestamp: format!("{}Z", now_secs()),
        logs: guard.logs.clone(),
    }
}

#[tauri::command]
fn trigger_jvm_gc() -> JvmStatusSnapshot {
    if let Ok(mut guard) = ACTIVE_JVM.lock() {
        guard.gc_collections += 1;
    }
    push_jvm_log(
        "INFO",
        "Launcher",
        "JVM heap telemetry sampled (G1GC manages live collections automatically).".into(),
    );
    get_jvm_status()
}

#[tauri::command]
fn stop_jvm_session() -> JvmStatusSnapshot {
    if let Ok(mut guard) = ACTIVE_JVM.lock() {
        if let Some(mut child) = guard.child.take() {
            let _ = child.kill();
            let _ = child.wait();
        }
        guard.pid = None;
    }
    push_jvm_log(
        "INFO",
        "Launcher",
        "Stopped Minecraft 1.8.9 client process.".into(),
    );
    get_jvm_status()
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            get_system_info,
            get_default_paths,
            load_settings,
            save_settings,
            load_extras,
            save_extras,
            load_launch_history,
            pick_folder,
            list_directory,
            list_mod_jars,
            add_mod_jars,
            toggle_mod_jar,
            delete_mod_jar,
            open_mods_folder,
            check_ornithe_preflight,
            download_ornithe_and_mods,
            get_download_status,
            reset_version_cache,
            launch_minecraft,
            get_jvm_status,
            trigger_jvm_gc,
            stop_jvm_session
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
