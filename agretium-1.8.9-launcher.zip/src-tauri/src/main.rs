#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    agretium_launcher_lib::run()
}
