import { useEffect, useState } from 'react';
import { Check, Plus, Trash2, User, X } from 'lucide-react';
import {
  createOfflineAccount,
  DEFAULT_ACCOUNTS,
  type AccountProfile,
} from '../utils/launcherLogic';

interface AccountModalProps {
  isOpen: boolean;
  accounts: AccountProfile[];
  activeAccount: string;
  onSelectAccount: (username: string) => void;
  onAddAccount: (profile: AccountProfile) => void;
  onDeleteAccount: (username: string) => void;
  onClose: () => void;
}

const DEFAULT_USERNAMES = new Set(DEFAULT_ACCOUNTS.map((a) => a.username));

export function AccountModal({
  isOpen,
  accounts,
  activeAccount,
  onSelectAccount,
  onAddAccount,
  onDeleteAccount,
  onClose,
}: AccountModalProps) {
  const [newUsername, setNewUsername] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createOfflineAccount(newUsername, accounts);
    if (!result.valid || !result.profile) {
      setError(result.error ?? 'Invalid offline username.');
      return;
    }
    setError(null);
    onAddAccount(result.profile);
    onSelectAccount(result.profile.username);
    setNewUsername('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="account-modal-title"
    >
      <div className="w-full max-w-md rounded-lg border border-[#2d3239] bg-[#191c20] shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-[#2d3239] px-5 py-4">
          <div>
            <h2 id="account-modal-title" className="text-base font-semibold text-stone-100">
              Player Accounts
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Switch accounts or add an Offline 1.8.9 profile.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close accounts dialog"
            className="rounded-md p-2 text-stone-400 hover:bg-[#22262b] hover:text-stone-100 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="max-h-60 overflow-y-auto divide-y divide-[#252930] rounded-md border border-[#2d3239] bg-[#111315]">
            {accounts.map((acc) => {
              const selected = acc.username === activeAccount;
              const isCustomOffline = acc.type === 'Offline' && !DEFAULT_USERNAMES.has(acc.username);
              return (
                <div
                  key={acc.username}
                  className={`flex items-center justify-between transition-colors ${
                    selected ? 'bg-[#142029]' : 'hover:bg-[#191c20]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSelectAccount(acc.username);
                      onClose();
                    }}
                    className="flex flex-1 items-center justify-between px-4 py-3 text-left min-w-0"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-8 w-8 items-center justify-center rounded bg-[#22262b] text-stone-200 shrink-0">
                        <User className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-stone-100 truncate">
                          {acc.username}
                        </div>
                        <div className="text-xs text-stone-400">
                          {acc.type} Account
                        </div>
                      </div>
                    </div>
                    {selected && <Check className="h-4 w-4 text-[#1cb5f6] shrink-0" />}
                  </button>
                  {isCustomOffline && (
                    <button
                      type="button"
                      onClick={() => onDeleteAccount(acc.username)}
                      aria-label={`Remove ${acc.username}`}
                      className="mr-3 rounded p-1.5 text-stone-500 hover:bg-red-950/50 hover:text-red-300 transition-colors shrink-0"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <form onSubmit={handleAdd} className="space-y-2.5 pt-1">
            <label htmlFor="new-account-input" className="block text-xs font-medium text-stone-300">
              Add Offline Account
            </label>
            <div className="flex gap-2">
              <input
                id="new-account-input"
                type="text"
                value={newUsername}
                onChange={(e) => {
                  setNewUsername(e.target.value);
                  setError(null);
                }}
                placeholder="OfflineUsername"
                className="flex-1 rounded-md border border-[#2d3239] bg-[#111315] px-3 py-2 text-sm text-stone-100 placeholder:text-stone-500 focus:border-[#1cb5f6] focus:outline-none"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add Offline</span>
              </button>
            </div>
            {error && <p role="alert" className="text-xs text-red-400">{error}</p>}
          </form>
        </div>
      </div>
    </div>
  );
}
