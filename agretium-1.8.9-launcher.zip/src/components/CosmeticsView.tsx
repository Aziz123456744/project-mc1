import { Check } from 'lucide-react';
import {
  CLOAK_CATALOG,
  LOCKED_VERSION_ID,
  type CloakCosmetic,
} from '../utils/launcherLogic';

interface CosmeticsViewProps {
  account: string;
  agretiumEnabled: boolean;
  equippedCloakId: string;
  onSelectCloak: (cloakId: string) => void;
  onEnableAgretium: () => void;
  onBackHome: () => void;
}

function CloakSvgPreview({ cloak }: { cloak: CloakCosmetic }) {
  return (
    <div
      data-testid="cloak-preview"
      className="flex h-full flex-col items-center justify-center rounded-xl border border-[#26282e] bg-[#121316] p-6"
    >
      <svg
        viewBox="0 0 120 180"
        className="h-48 w-32 drop-shadow-lg"
        role="img"
        aria-label={`${cloak.name} voxel preview`}
      >
        {/* Player Head & Shoulders silhouette */}
        <rect x="38" y="8" width="44" height="44" rx="4" fill="#2a2d35" stroke="#3c404a" strokeWidth="2" />
        <rect x="46" y="24" width="8" height="6" fill="#64748b" />
        <rect x="66" y="24" width="8" height="6" fill="#64748b" />
        <rect x="24" y="54" width="72" height="16" rx="3" fill="#23262d" />

        {/* Voxel Cape Body */}
        <rect
          x="26"
          y="60"
          width="68"
          height="112"
          rx="4"
          fill={cloak.secondaryColor}
          stroke={cloak.primaryColor}
          strokeWidth="3"
        />

        {cloak.pattern === 'emblem' && (
          <>
            <polygon
              points="60,82 80,104 60,126 40,104"
              fill={cloak.primaryColor}
            />
            <rect x="53" y="97" width="14" height="14" fill={cloak.secondaryColor} />
            <rect x="34" y="152" width="52" height="8" fill={cloak.primaryColor} opacity="0.85" />
          </>
        )}

        {cloak.pattern === 'chevron' && (
          <>
            <polyline
              points="36,92 60,114 84,92"
              fill="none"
              stroke={cloak.primaryColor}
              strokeWidth="8"
              strokeLinecap="square"
            />
            <polyline
              points="36,122 60,144 84,122"
              fill="none"
              stroke={cloak.primaryColor}
              strokeWidth="8"
              strokeLinecap="square"
              opacity="0.7"
            />
          </>
        )}

        {cloak.pattern === 'horizon' && (
          <>
            <rect x="30" y="96" width="60" height="14" fill={cloak.primaryColor} />
            <rect x="30" y="116" width="60" height="6" fill={cloak.primaryColor} opacity="0.65" />
            <rect x="30" y="128" width="60" height="3" fill={cloak.primaryColor} opacity="0.4" />
          </>
        )}

        {cloak.pattern === 'crest' && (
          <>
            <path
              d="M42 86 H78 V118 L60 138 L42 118 Z"
              fill={cloak.primaryColor}
            />
            <rect x="54" y="96" width="12" height="22" fill={cloak.secondaryColor} />
          </>
        )}

        {cloak.pattern === 'none' && (
          <line
            x1="36"
            y1="72"
            x2="84"
            y2="160"
            stroke="#3f434c"
            strokeWidth="3"
            strokeDasharray="6 6"
          />
        )}
      </svg>
      <div className="mt-4 text-center">
        <div className="text-sm font-bold text-white">{cloak.name}</div>
        <div className="text-xs text-stone-400 mt-0.5">{cloak.subtitle}</div>
      </div>
    </div>
  );
}

export function CosmeticsView({
  account,
  agretiumEnabled,
  equippedCloakId,
  onSelectCloak,
  onEnableAgretium,
  onBackHome,
}: CosmeticsViewProps) {
  const activeCloak =
    CLOAK_CATALOG.find((c) => c.id === equippedCloakId) ?? CLOAK_CATALOG[0];

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            1.8.9 Cloaks & Cosmetics
          </h1>
          <p className="text-xs text-stone-400 mt-1">
            Profile: {account} · Minecraft {LOCKED_VERSION_ID} ·{' '}
            {agretiumEnabled ? 'Agretium Cape Layer Active' : 'Agretium Required for Cloak'}
          </p>
        </div>

        <button
          type="button"
          onClick={onBackHome}
          className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap shrink-0"
        >
          Return to Play
        </button>
      </div>

      {!agretiumEnabled && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl border border-amber-700/50 bg-amber-950/20 p-4">
          <div className="text-xs text-amber-200">
            Agretium is currently disabled for 1.8.9. Enable Agretium so your equipped cloak renders in-game.
          </div>
          <button
            type="button"
            onClick={onEnableAgretium}
            className="rounded-md bg-[#1cb5f6] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#38c6ff] whitespace-nowrap shrink-0"
          >
            Enable Agretium
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
        <div className="md:col-span-5">
          <CloakSvgPreview cloak={activeCloak} />
        </div>

        <div className="md:col-span-7 space-y-2.5">
          {CLOAK_CATALOG.map((cloak) => {
            const selected = cloak.id === activeCloak.id;
            return (
              <button
                key={cloak.id}
                type="button"
                onClick={() => onSelectCloak(cloak.id)}
                aria-pressed={selected}
                className={`flex w-full items-center justify-between gap-4 rounded-xl border p-4 text-left transition-colors ${
                  selected
                    ? 'border-[#1cb5f6] bg-[#142029]'
                    : 'border-[#26282e] bg-[#181a1f] hover:border-[#383c46]'
                }`}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <span
                    aria-hidden="true"
                    style={{
                      backgroundColor: cloak.secondaryColor,
                      borderColor: cloak.primaryColor,
                    }}
                    className="h-9 w-7 rounded border-2 shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-white truncate">
                      {cloak.name}
                    </div>
                    <div className="text-xs text-stone-400 truncate mt-0.5">
                      {cloak.subtitle}
                    </div>
                  </div>
                </div>

                <span
                  className={`inline-flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap shrink-0 ${
                    selected
                      ? 'bg-[#1cb5f6] text-white'
                      : 'border border-[#2c2f36] bg-[#121316] text-stone-300'
                  }`}
                >
                  {selected && <Check className="h-3.5 w-3.5" />}
                  <span>{selected ? 'Equipped' : 'Equip'}</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
