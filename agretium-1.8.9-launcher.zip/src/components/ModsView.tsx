import { useMemo, useRef, useState, type ChangeEvent } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  ExternalLink,
  FolderOpen,
  Package,
  Plus,
  RotateCcw,
  Search,
  Sliders,
  Trash2,
} from 'lucide-react';
import {
  ARGENTUM_MOD_JARS,
  ARGENTUM_RELEASES_URL,
  filterMods,
  formatFileSize,
  joinPlatformPath,
  LOCKED_VERSION_ID,
  type AgretiumMod,
  type ModCategory,
  type ModJarFile,
} from '../utils/launcherLogic';
import { isTauriDesktopRuntime } from '../utils/api';

interface ModsViewProps {
  mods: AgretiumMod[];
  modJars: ModJarFile[];
  mcPath: string;
  modJarBusy: boolean;
  modJarError: string | null;
  agretiumEnabled: boolean;
  newGcEnabled: boolean;
  argentumOk: boolean;
  onToggleMod: (modId: string) => void;
  onToggleAgretium: () => void;
  onToggleNewGc: () => void;
  onInstallArgentumJars: () => void;
  onAddModJarsTauri: () => void;
  onUploadWebModJars: (files: Array<{ fileName: string; base64Data: string }>) => void;
  onToggleModJar: (fileName: string, enabled: boolean) => void;
  onDeleteModJar: (fileName: string) => void;
  onOpenModsFolder: () => void;
  onResetMods: () => void;
  onBackHome: () => void;
}

const CATEGORIES: Array<'All' | ModCategory> = [
  'All',
  'FPS & Rendering',
  'PvP HUD',
  'Utility',
];

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error(`Failed reading ${file.name}`));
    reader.readAsDataURL(file);
  });
}

export function ModsView({
  mods,
  modJars,
  mcPath,
  modJarBusy,
  modJarError,
  agretiumEnabled,
  newGcEnabled,
  argentumOk,
  onToggleMod,
  onToggleAgretium,
  onToggleNewGc,
  onInstallArgentumJars,
  onAddModJarsTauri,
  onUploadWebModJars,
  onToggleModJar,
  onDeleteModJar,
  onOpenModsFolder,
  onResetMods,
  onBackHome,
}: ModsViewProps) {
  const [category, setCategory] = useState<'All' | ModCategory>('All');
  const [search, setSearch] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const isTauri = isTauriDesktopRuntime();

  const filteredMods = useMemo(
    () => filterMods(mods, { category, search }),
    [mods, category, search]
  );

  const enabledCount = mods.filter((m) => m.enabled).length;
  const activeJarCount = modJars.filter((j) => j.enabled).length;
  const modsDirPath = joinPlatformPath(mcPath, 'mods');

  const handleWebFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (selected.length === 0) return;

    const payload = await Promise.all(
      selected.map(async (f) => ({
        fileName: f.name,
        base64Data: await readFileAsBase64(f),
      }))
    );
    onUploadWebModJars(payload);
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            1.8.9 Ornithe &amp; Agretium Mods
          </h1>
          <p className="text-xs text-stone-400 mt-1 tabular-nums">
            Minecraft {LOCKED_VERSION_ID} · Ornithe 0.20.1 Gen2 · Java 25 · {activeJarCount}{' '}
            JARs active · {enabledCount} HUD modules
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onResetMods}
            className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#181a1f] px-3.5 py-2 text-xs font-medium text-stone-300 hover:text-white hover:border-[#3c404a] transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Mods</span>
          </button>
          <button
            type="button"
            onClick={onBackHome}
            className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap shrink-0"
          >
            Back to Home
          </button>
        </div>
      </div>

      {/* Core Engine Toggles */}
      <section className="rounded-xl border border-[#26282e] bg-[#181a1f] divide-y divide-[#24262c]">
        <div className="flex items-center justify-between p-4 sm:px-5 gap-4">
          <div className="min-w-0">
            <div className="text-sm font-semibold text-white">
              Agretium Engine (1.8.9)
            </div>
            <div className="text-xs text-stone-400 mt-0.5">
              Dynamic lights, zoom, custom sky, and chunk rendering optimizations.
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={agretiumEnabled}
            aria-label="Toggle Agretium Engine"
            onClick={onToggleAgretium}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
              agretiumEnabled ? 'bg-[#1cb5f6]' : 'bg-[#42454e]'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                agretiumEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <div className="flex items-center justify-between p-4 sm:px-5 gap-4">
          <div className="min-w-0">
            <div className="text-sm font-semibold text-white">
              G1 Garbage Collector Tuning
            </div>
            <div className="text-xs text-stone-400 mt-0.5">
              Appends <code className="font-mono text-stone-300">-XX:+UseG1GC</code> to JVM flags to smooth frame pacing.
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={newGcEnabled}
            aria-label="Toggle G1 Garbage Collector Tuning"
            onClick={onToggleNewGc}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
              newGcEnabled ? 'bg-[#1cb5f6]' : 'bg-[#42454e]'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                newGcEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </section>

      {/* Installed Mods Folder (mods/) - Core + Custom User .jar Mods */}
      <section
        aria-label="Installed Mods Folder"
        className="rounded-xl border border-[#26282e] bg-[#181a1f] p-4 sm:p-5 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-white">
              Installed Mods Folder (<code className="font-mono text-[#7dd9fc]">mods/</code>)
            </h2>
            <p className="font-mono text-[11px] text-stone-400 mt-0.5 truncate">
              {modsDirPath}
            </p>
            <p className="text-xs text-stone-400 mt-1">
              Drop or add 1.8.9 Ornithe or Forge (.jar) mods here — active JARs launch automatically with the game.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isTauri && (
              <button
                type="button"
                onClick={onOpenModsFolder}
                className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#121316] px-3 py-2 text-xs font-medium text-stone-200 hover:border-[#3c404a] hover:text-white transition-colors whitespace-nowrap"
              >
                <FolderOpen className="h-3.5 w-3.5" />
                <span>Open Folder</span>
              </button>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept=".jar"
              multiple
              aria-label="Upload .jar mod file"
              onChange={(e) => void handleWebFileChange(e)}
              className="hidden"
            />
            <button
              type="button"
              disabled={modJarBusy}
              onClick={() => {
                if (isTauri) {
                  onAddModJarsTauri();
                } else {
                  fileInputRef.current?.click();
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] disabled:opacity-60 transition-colors whitespace-nowrap"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{modJarBusy ? 'Adding...' : 'Add Mod (.jar)'}</span>
            </button>
          </div>
        </div>

        {modJarError && (
          <div
            role="alert"
            className="flex items-center gap-2 rounded-md border border-red-800/70 bg-red-950/30 px-3 py-2 text-xs text-red-200"
          >
            <AlertCircle className="h-4 w-4 text-red-400 shrink-0" />
            <span>{modJarError}</span>
          </div>
        )}

        {modJars.length === 0 ? (
          <div className="rounded-lg border border-dashed border-[#2c2f36] bg-[#121316] p-6 text-center space-y-2">
            <Package className="h-6 w-6 text-stone-500 mx-auto" />
            <p className="text-xs text-stone-300">
              No <code className="font-mono text-stone-200">.jar</code> mods detected in{' '}
              <code className="font-mono text-stone-200">mods/</code> yet.
            </p>
            <p className="text-[11px] text-stone-500">
              Click Add Mod (.jar) or Download Argentum JARs below to populate Ornithe 1.8.9 mods.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[#23252a] rounded-lg border border-[#26282e] bg-[#121316]">
            {modJars.map((jar) => (
              <div
                key={jar.fileName}
                className="flex items-center justify-between gap-3 px-3.5 py-2.5"
              >
                <div className="min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-mono text-xs font-semibold truncate ${
                        jar.enabled ? 'text-stone-100' : 'text-stone-500 line-through'
                      }`}
                    >
                      {jar.baseName}
                    </span>
                    <span className="text-[11px] text-stone-400 shrink-0">
                      {jar.isCoreArgentum ? 'Core' : 'Custom'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-stone-500 font-mono tabular-nums">
                    <span>{formatFileSize(jar.sizeBytes)}</span>
                    <span aria-hidden="true">·</span>
                    <span className={jar.enabled ? 'text-emerald-400' : 'text-stone-500'}>
                      {jar.enabled ? 'Enabled (.jar)' : 'Disabled (.jar.disabled)'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    role="switch"
                    aria-checked={jar.enabled}
                    aria-label={`Toggle mod ${jar.displayName}`}
                    disabled={modJarBusy}
                    onClick={() => onToggleModJar(jar.fileName, !jar.enabled)}
                    className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors disabled:opacity-60 ${
                      jar.enabled ? 'bg-[#1cb5f6]' : 'bg-[#42454e]'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                        jar.enabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>

                  {!jar.isCoreArgentum && (
                    <button
                      type="button"
                      disabled={modJarBusy}
                      aria-label={`Delete mod ${jar.displayName}`}
                      onClick={() => onDeleteModJar(jar.fileName)}
                      className="rounded p-1.5 text-stone-500 hover:bg-red-950/50 hover:text-red-300 disabled:opacity-50 transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Argentum 1.0.2 + Ornithe Standard Libraries + Pylon + ForgeCompat Bundle */}
      <section className="rounded-xl border border-[#26282e] bg-[#181a1f] p-4 sm:p-5 space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">
                Ornithe 1.8.9 Core &amp; ForgeCompat Bundle
              </h2>
              <span
                className={`text-[11px] font-medium ${
                  argentumOk ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {argentumOk ? 'Installed in mods/' : 'Missing JARs'}
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              Bundled from{' '}
              <a
                href={ARGENTUM_RELEASES_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-[#1cb5f6] hover:underline"
              >
                <span>QuicksilverMC/Argentum Releases</span>
                <ExternalLink className="h-3 w-3" />
              </a>{' '}
              with Ornithe Standard Libraries, Pylon, and Polyfrost ForgeCompat.
            </p>
          </div>

          {!argentumOk ? (
            <button
              type="button"
              onClick={onInstallArgentumJars}
              className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download Argentum JARs</span>
            </button>
          ) : (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400 shrink-0 tabular-nums">
              <CheckCircle2 className="h-4 w-4" />
              <span>
                {ARGENTUM_MOD_JARS.length}/{ARGENTUM_MOD_JARS.length} JARs Verified
              </span>
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {ARGENTUM_MOD_JARS.map((jar) => (
            <div
              key={jar.id}
              className="rounded-lg border border-[#26282e] bg-[#121316] p-3 space-y-1"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs font-semibold text-[#7dd9fc] truncate">
                  {jar.fileName}
                </span>
                <span className="font-mono text-[11px] text-stone-400 shrink-0">
                  {jar.sizeLabel}
                </span>
              </div>
              <p className="text-[11px] text-stone-400 leading-relaxed">{jar.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div
          role="group"
          aria-label="Filter 1.8.9 mods by category"
          className="flex flex-wrap items-center gap-1 rounded-lg bg-[#181a1f] border border-[#26282e] p-1"
        >
          {CATEGORIES.map((cat) => {
            const active = category === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#1cb5f6] text-white'
                    : 'text-stone-400 hover:text-stone-100'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        <div className="relative w-full md:w-64">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-stone-500"
            aria-hidden="true"
          />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search 1.8.9 modules"
            placeholder="Search modules..."
            className="w-full rounded-lg border border-[#26282e] bg-[#181a1f] pl-9 pr-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:border-[#1cb5f6] focus:outline-none"
          />
        </div>
      </div>

      {/* Module List */}
      {filteredMods.length === 0 ? (
        <div className="rounded-xl border border-[#26282e] bg-[#181a1f] p-8 text-center space-y-3">
          <Sliders className="h-6 w-6 text-stone-500 mx-auto" />
          <p className="text-sm text-stone-300">
            No 1.8.9 modules match your current filter.
          </p>
          <button
            type="button"
            onClick={() => {
              setCategory('All');
              setSearch('');
            }}
            className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-semibold text-white hover:bg-[#38c6ff]"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredMods.map((mod) => (
            <div
              key={mod.id}
              className="flex items-start justify-between gap-4 rounded-xl border border-[#26282e] bg-[#181a1f] p-4"
            >
              <div className="min-w-0 space-y-1">
                <div className="flex items-center gap-2 text-xs text-stone-400">
                  <span>{mod.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{mod.enabled ? 'Active' : 'Disabled'}</span>
                </div>
                <h2 className="text-sm font-bold text-white truncate">{mod.name}</h2>
                <p className="text-xs text-stone-400 leading-relaxed">
                  {mod.description}
                </p>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={mod.enabled}
                aria-label={`Toggle ${mod.name}`}
                onClick={() => onToggleMod(mod.id)}
                className={`relative mt-1 inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
                  mod.enabled ? 'bg-[#1cb5f6]' : 'bg-[#42454e]'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                    mod.enabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
