import { useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  RotateCcw,
  Save,
  Settings,
  User,
} from 'lucide-react';
import {
  RESOLUTION_PRESETS,
  buildJvmArguments,
  formatRamGb,
  getMaxSafeRamMb,
  validateLauncherSettings,
  type LauncherPreferences,
  type LauncherSettings,
  type LaunchHistoryEntry,
  type OrnitheConfig,
  type SystemInfo,
} from '../utils/launcherLogic';
import { JvmStatus } from './JvmStatus';

export type SettingsSubTab =
  | 'game'
  | 'launcher'
  | 'account'
  | 'social'
  | 'privacy'
  | 'debug'
  | 'premium';

interface SettingsViewProps {
  activeSubTab: SettingsSubTab;
  onChangeSubTab: (tab: SettingsSubTab) => void;
  settings: LauncherSettings;
  ornithe: OrnitheConfig;
  preferences: LauncherPreferences;
  systemInfo: SystemInfo;
  configPath: string;
  history: LaunchHistoryEntry[];
  dirty: boolean;
  saving: boolean;
  saveMessage: string | null;
  saveError: string | null;
  onChangeSetting: <K extends keyof LauncherSettings>(
    key: K,
    value: LauncherSettings[K]
  ) => void;
  onToggleOrnithe: (enabled: boolean) => void;
  onChangePreference: <K extends keyof LauncherPreferences>(
    key: K,
    value: LauncherPreferences[K]
  ) => void;
  onSave: () => void;
  onResetDefaults: () => void;
  onPickFolder: (field: 'mc_path' | 'java_path') => void;
  onOpenAccounts: () => void;
  onQuickLaunch: () => void;
}

interface CyanSwitchProps {
  id: string;
  label: string;
  description?: string;
  checked: boolean;
  onChange: (next: boolean) => void;
}

function CyanSwitch({ id, label, description, checked, onChange }: CyanSwitchProps) {
  return (
    <div className="flex items-center justify-between gap-6 py-3.5">
      <div className="min-w-0">
        <label htmlFor={id} className="block text-sm font-semibold text-stone-100 cursor-pointer">
          {label}
        </label>
        {description && <p className="text-xs text-stone-400 mt-0.5">{description}</p>}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-12 shrink-0 cursor-pointer items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1cb5f6] ${
          checked ? 'bg-[#1cb5f6]' : 'bg-[#6b7280]'
        }`}
      >
        <span
          className={`inline-block h-4.5 w-4.5 rounded-full bg-white shadow transition-transform duration-150 ${
            checked ? 'translate-x-6.5' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  );
}

const SUB_TABS: Array<{ id: SettingsSubTab; label: string }> = [
  { id: 'game', label: 'Game' },
  { id: 'launcher', label: 'Launcher' },
  { id: 'account', label: 'Account' },
  { id: 'social', label: 'Social' },
  { id: 'privacy', label: 'Privacy' },
  { id: 'debug', label: 'Debug' },
  { id: 'premium', label: 'Premium' },
];

export function SettingsView({
  activeSubTab,
  onChangeSubTab,
  settings,
  ornithe,
  preferences,
  systemInfo,
  configPath,
  history,
  dirty,
  saving,
  saveMessage,
  saveError,
  onChangeSetting,
  onToggleOrnithe,
  onChangePreference,
  onSave,
  onResetDefaults,
  onPickFolder,
  onOpenAccounts,
  onQuickLaunch,
}: SettingsViewProps) {
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [friendRequests, setFriendRequests] = useState(true);
  const [showActiveServer, setShowActiveServer] = useState(true);
  const [crashDiagnostics, setCrashDiagnostics] = useState(true);
  const [cloakVisible, setCloakVisible] = useState(true);

  const maxSafeRam = getMaxSafeRamMb(systemInfo.total_ram_mb);
  const validation = validateLauncherSettings(settings, systemInfo.total_ram_mb);
  const jvmSpec = buildJvmArguments(settings, ornithe);
  const sliderPct = Math.round(
    ((settings.ram_mb - 1024) / Math.max(1, maxSafeRam - 1024)) * 100
  );

  const handleCopyCommand = async () => {
    try {
      await navigator.clipboard.writeText(jvmSpec.commandLine);
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 1800);
    } catch {
      // ignore clipboard restrictions
    }
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSave();
      }}
      className="mx-auto max-w-3xl space-y-6 pb-6"
    >
      {/* Centered 7-Tab Underline Bar matching reference Screenshots 2 & 3 */}
      <nav
        aria-label="Settings Categories"
        className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 border-b border-[#23252a] pt-1"
      >
        {SUB_TABS.map((tab) => {
          const active = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onChangeSubTab(tab.id)}
              className={`pb-3 text-sm font-medium transition-colors border-b-2 whitespace-nowrap shrink-0 ${
                active
                  ? 'border-[#1cb5f6] text-white font-semibold'
                  : 'border-transparent text-stone-400 hover:text-stone-200'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </nav>

      {saveMessage && (
        <div
          role="status"
          className="flex items-center gap-2.5 rounded-md border border-[#1cb5f6]/50 bg-[#142029] px-4 py-2.5 text-xs text-[#9ce2fe]"
        >
          <Check className="h-4 w-4 text-[#1cb5f6] shrink-0" />
          <span>{saveMessage}</span>
        </div>
      )}

      {saveError && (
        <div
          role="alert"
          className="flex items-center gap-2.5 rounded-md border border-red-800/70 bg-red-950/30 px-4 py-2.5 text-xs text-red-200"
        >
          <AlertCircle className="h-4 w-4 text-red-400 shrink-0" />
          <span>{saveError}</span>
        </div>
      )}

      {/* TAB 1: GAME (Matches Screenshot 2) */}
      {activeSubTab === 'game' && (
        <div className="space-y-6">
          {/* Allocate RAM (MB) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-4">
              <div>
                <label htmlFor="ram-slider" className="block text-sm font-bold text-stone-100">
                  Allocate RAM (MB)
                </label>
                <p className="text-xs text-stone-400 mt-0.5">
                  Amount of RAM reserved for Minecraft 1.8.9. We recommend 4096MB (Host:{' '}
                  <span className="font-mono tabular-nums">{systemInfo.total_ram_mb} MB</span>)
                </p>
              </div>
              <div className="rounded-md border border-[#1cb5f6] bg-[#14161a] px-5 py-2 font-mono text-xs font-semibold text-stone-100 tabular-nums shrink-0">
                {settings.ram_mb} MB
              </div>
            </div>

            <div className="space-y-1.5 pt-1">
              <input
                id="ram-slider"
                type="range"
                min={1024}
                max={maxSafeRam}
                step={256}
                value={settings.ram_mb}
                onChange={(e) => onChangeSetting('ram_mb', Number(e.target.value))}
                style={{
                  background: `linear-gradient(to right, #1cb5f6 0%, #1cb5f6 ${sliderPct}%, #2b2e35 ${sliderPct}%, #2b2e35 100%)`,
                  height: '5px',
                  borderRadius: '999px',
                }}
                className="launcher-slider w-full"
              />
              <div className="flex justify-between font-mono text-[11px] font-semibold text-stone-300 tabular-nums">
                <span>1024 MB</span>
                <span>{maxSafeRam} MB</span>
              </div>
            </div>
            {validation.errors.ram_mb && (
              <p className="text-xs text-red-400">{validation.errors.ram_mb}</p>
            )}
          </div>

          <hr className="border-[#23252a]" />

          {/* Minecraft Path & Java Path */}
          <div className="space-y-4">
            <div>
              <label
                htmlFor="mc-path-input"
                className="block text-sm font-bold text-stone-100 mb-2"
              >
                Minecraft Path
              </label>
              <div className="flex gap-2">
                <input
                  id="mc-path-input"
                  type="text"
                  value={settings.mc_path}
                  onChange={(e) => onChangeSetting('mc_path', e.target.value)}
                  className="flex-1 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2.5 font-mono text-xs text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => onPickFolder('mc_path')}
                  aria-label="Browse Minecraft Path"
                  className="flex h-10 w-10 items-center justify-center rounded-md border border-[#1cb5f6]/80 bg-[#181a1f] text-stone-100 hover:bg-[#1e252d] transition-colors shrink-0"
                >
                  <Settings className="h-4 w-4" />
                </button>
              </div>
              {validation.errors.mc_path && (
                <p className="text-xs text-red-400 mt-1">{validation.errors.mc_path}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="java-path-input"
                className="block text-sm font-bold text-stone-100 mb-2"
              >
                Java Path
              </label>
              <div className="flex gap-2">
                <input
                  id="java-path-input"
                  type="text"
                  value={settings.java_path}
                  onChange={(e) => onChangeSetting('java_path', e.target.value)}
                  className="flex-1 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2.5 font-mono text-xs text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => onPickFolder('java_path')}
                  aria-label="Browse Java Path"
                  className="flex h-10 w-10 items-center justify-center rounded-md border border-[#1cb5f6]/80 bg-[#181a1f] text-stone-100 hover:bg-[#1e252d] transition-colors shrink-0"
                >
                  <Settings className="h-4 w-4" />
                </button>
              </div>
              {validation.errors.java_path && (
                <p className="text-xs text-red-400 mt-1">{validation.errors.java_path}</p>
              )}
            </div>
          </div>

          <hr className="border-[#23252a]" />

          {/* Resolution, Log Retention, GC, OptiFine */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <label
                  htmlFor="resolution-select"
                  className="block text-sm font-bold text-stone-100"
                >
                  Minecraft Resolution
                </label>
                <p className="text-xs text-stone-400 mt-0.5">
                  Select the default resolution of Minecraft
                </p>
              </div>
              <select
                id="resolution-select"
                value={settings.resolution}
                onChange={(e) => onChangeSetting('resolution', e.target.value)}
                className="w-full sm:w-52 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2 text-center font-mono text-xs font-medium text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
              >
                {RESOLUTION_PRESETS.map((preset) => (
                  <option key={preset.value} value={preset.value}>
                    {preset.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <label
                  htmlFor="log-retention-select"
                  className="block text-sm font-bold text-stone-100"
                >
                  Minecraft Log Retention
                </label>
                <p className="text-xs text-stone-400 mt-0.5">
                  Select how long you would like to keep your Minecraft log
                </p>
              </div>
              <select
                id="log-retention-select"
                value={preferences.logRetention}
                onChange={(e) =>
                  onChangePreference(
                    'logRetention',
                    e.target.value as LauncherPreferences['logRetention']
                  )
                }
                className="w-full sm:w-52 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2 text-xs font-medium text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
              >
                <option value="Forever">Forever</option>
                <option value="30 Days">30 Days</option>
                <option value="7 Days">7 Days</option>
                <option value="Session Only">Session Only</option>
              </select>
            </div>

            <CyanSwitch
              id="switch-new-gc"
              label="Enable New Garbage Collector"
              checked={settings.new_gc}
              onChange={(val) => onChangeSetting('new_gc', val)}
            />

            <CyanSwitch
              id="switch-optifine"
              label="Enable Agretium for Minecraft 1.8.9"
              description="Applies Agretium shader and FPS optimizations on launch."
              checked={settings.optifine}
              onChange={(val) => onChangeSetting('optifine', val)}
            />

            <CyanSwitch
              id="switch-ornithe"
              label={`Enable Ornithe 1.8.9 Loader (${ornithe.loaderVersion})`}
              description="Boots Minecraft 1.8.9 through Fabric KnotClient with Calamus 1.8.9 mappings."
              checked={ornithe.enabled}
              onChange={onToggleOrnithe}
            />
          </div>
        </div>
      )}

      {/* TAB 2: LAUNCHER (Matches Screenshot 3) */}
      {activeSubTab === 'launcher' && (
        <div className="space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3">
            <label
              htmlFor="startup-select"
              className="text-sm font-semibold text-stone-100"
            >
              Launch client when your computer starts up.
            </label>
            <select
              id="startup-select"
              value={preferences.startupBehavior}
              onChange={(e) =>
                onChangePreference(
                  'startupBehavior',
                  e.target.value as LauncherPreferences['startupBehavior']
                )
              }
              className="w-full sm:w-56 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2 text-xs font-medium text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
            >
              <option value="Do not start">Do not start</option>
              <option value="Start minimized">Start minimized</option>
              <option value="Open window">Open window</option>
            </select>
          </div>

          <CyanSwitch
            id="switch-minimize-launch"
            label="Minimize Launcher when Minecraft is running."
            checked={settings.minimize_on_launch}
            onChange={(val) => onChangeSetting('minimize_on_launch', val)}
          />

          <CyanSwitch
            id="switch-offline-prompt"
            label="Launch Minecraft if authentication servers are offline without a confirmation prompt."
            checked={preferences.launchOfflineWithoutPrompt}
            onChange={(val) => onChangePreference('launchOfflineWithoutPrompt', val)}
          />

          <CyanSwitch
            id="switch-close-shutdown"
            label="Close Launcher when Minecraft shuts down."
            checked={preferences.closeOnShutdown}
            onChange={(val) => onChangePreference('closeOnShutdown', val)}
          />

          <CyanSwitch
            id="switch-hide-jar"
            label="Hide jar update window when patching."
            checked={preferences.hideJarUpdateWindow}
            onChange={(val) => onChangePreference('hideJarUpdateWindow', val)}
          />

          <CyanSwitch
            id="switch-shutdown-running"
            label="Shutdown launcher even if Minecraft is still running (which will close Minecraft automatically)."
            checked={preferences.shutdownWhileRunning}
            onChange={(val) => onChangePreference('shutdownWhileRunning', val)}
          />

          <CyanSwitch
            id="switch-desktop-notif"
            label="Enable desktop notifications."
            checked={preferences.desktopNotifications}
            onChange={(val) => onChangePreference('desktopNotifications', val)}
          />

          <hr className="border-[#23252a] my-3" />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3">
            <label
              htmlFor="patch-bg-select"
              className="text-sm font-semibold text-stone-100"
            >
              Patch minecraft in the background.
            </label>
            <select
              id="patch-bg-select"
              value={preferences.patchInBackground}
              onChange={(e) =>
                onChangePreference(
                  'patchInBackground',
                  e.target.value as LauncherPreferences['patchInBackground']
                )
              }
              className="w-full sm:w-56 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2 text-xs font-medium text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
            >
              <option value="Off">Off</option>
              <option value="On">On</option>
            </select>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3">
            <label
              htmlFor="language-select"
              className="text-sm font-semibold text-stone-100"
            >
              Language
            </label>
            <select
              id="language-select"
              value={preferences.language}
              onChange={(e) =>
                onChangePreference(
                  'language',
                  e.target.value as LauncherPreferences['language']
                )
              }
              className="w-full sm:w-56 rounded-md border border-[#1cb5f6]/80 bg-[#121316] px-3.5 py-2 text-xs font-medium text-stone-100 focus:border-[#1cb5f6] focus:outline-none"
            >
              <option value="English">English</option>
              <option value="Español">Español</option>
              <option value="Deutsch">Deutsch</option>
              <option value="Français">Français</option>
            </select>
          </div>
        </div>
      )}

      {/* TAB 3: ACCOUNT */}
      {activeSubTab === 'account' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-lg border border-[#26282e] bg-[#181a1f] p-5">
            <div className="flex items-center gap-3.5">
              <div className="flex h-12 w-12 items-center justify-center rounded-md bg-[#22252c] text-[#1cb5f6]">
                <User className="h-6 w-6" />
              </div>
              <div>
                <div className="text-base font-bold text-stone-100">{settings.account}</div>
                <div className="text-xs text-stone-400">
                  Active Minecraft 1.8.9 Launch Profile
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={onOpenAccounts}
              className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-semibold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap"
            >
              Switch / Add Account
            </button>
          </div>
        </div>
      )}

      {/* TAB 4: SOCIAL */}
      {activeSubTab === 'social' && (
        <div className="divide-y divide-[#23252a]">
          <CyanSwitch
            id="switch-friend-req"
            label="Allow incoming 1.8.9 friend requests"
            description="Players on your current server can send friend invites."
            checked={friendRequests}
            onChange={setFriendRequests}
          />
          <CyanSwitch
            id="switch-rich-presence"
            label="Show active server in friends list"
            description="Broadcasts which 1.8.9 server tile you launched into."
            checked={showActiveServer}
            onChange={setShowActiveServer}
          />
        </div>
      )}

      {/* TAB 5: PRIVACY */}
      {activeSubTab === 'privacy' && (
        <div className="divide-y divide-[#23252a]">
          <CyanSwitch
            id="switch-crash-diag"
            label="Store local JVM crash diagnostics"
            description="Retains stderr logs locally inside your Minecraft directory."
            checked={crashDiagnostics}
            onChange={setCrashDiagnostics}
          />
          <div className="py-4 text-xs text-stone-400">
            Settings are stored strictly locally in{' '}
            <code className="text-stone-200">{configPath}</code>.
          </div>
        </div>
      )}

      {/* TAB 6: DEBUG */}
      {activeSubTab === 'debug' && (
        <div className="space-y-5">
          <JvmStatus
            configuredXmxMb={settings.ram_mb}
            configuredNewGc={settings.new_gc}
            onQuickLaunch={onQuickLaunch}
          />

          <div className="rounded-lg border border-[#26282e] bg-[#181a1f] p-5 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-bold text-stone-100">
                  Generated Java 1.8.9 Launch Command
                </h2>
                <p className="text-xs text-stone-400 mt-0.5">
                  Allocated {settings.ram_mb} MB ({formatRamGb(settings.ram_mb)}) · Config file:{' '}
                  <span className="font-mono">{configPath}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={handleCopyCommand}
                className="inline-flex items-center gap-1.5 rounded-md border border-[#1cb5f6]/60 bg-[#121316] px-3 py-1.5 text-xs font-medium text-stone-100 hover:bg-[#1c232b]"
              >
                {copiedCmd ? (
                  <Check className="h-3.5 w-3.5 text-[#1cb5f6]" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
                <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="overflow-x-auto rounded-md border border-[#24262c] bg-[#121316] p-3.5 font-mono text-xs text-[#8fe0ff] whitespace-pre-wrap break-all">
              {jvmSpec.commandLine}
            </pre>
          </div>

          <div className="rounded-lg border border-[#26282e] bg-[#181a1f] overflow-hidden">
            <div className="border-b border-[#24262c] px-5 py-3 text-sm font-bold text-stone-100">
              Recent Launch History ({history.length})
            </div>
            {history.length === 0 ? (
              <div className="p-5 text-xs text-stone-400">
                No 1.8.9 launches recorded yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#24262c] text-stone-400">
                      <th className="px-4 py-2.5 font-medium">Version</th>
                      <th className="px-4 py-2.5 font-medium">Account</th>
                      <th className="px-4 py-2.5 font-medium text-right">RAM</th>
                      <th className="px-4 py-2.5 font-medium">Status</th>
                      <th className="px-4 py-2.5 font-medium text-right">Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#23252a]">
                    {history.slice(0, 8).map((item) => (
                      <tr key={item.id}>
                        <td className="px-4 py-2.5 font-mono text-stone-100">{item.version}</td>
                        <td className="px-4 py-2.5 text-stone-300">{item.account}</td>
                        <td className="px-4 py-2.5 text-right font-mono tabular-nums text-stone-300">
                          {item.ram_mb} MB
                        </td>
                        <td className="px-4 py-2.5">
                          <span
                            className={
                              item.status === 'launched'
                                ? 'text-[#1cb5f6] font-medium'
                                : 'text-red-400 font-medium'
                            }
                          >
                            {item.status === 'launched'
                              ? item.launchDurationMs !== undefined
                                ? `Launched (${(item.launchDurationMs / 1000).toFixed(2)}s)`
                                : 'Launched'
                              : 'Failed'}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono tabular-nums text-stone-400">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 7: PREMIUM */}
      {activeSubTab === 'premium' && (
        <div className="rounded-lg border border-[#26282e] bg-[#181a1f] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-stone-100">
                1.8.9 Cloak & Cosmetic Preview
              </h2>
              <p className="text-xs text-stone-400 mt-0.5">
                Exclusive free voxel cloak unlocked for your {settings.account} profile.
              </p>
            </div>
            <span className="font-mono text-xs font-semibold text-[#1cb5f6]">Unlocked</span>
          </div>
          <CyanSwitch
            id="switch-cloak-visible"
            label="Equip Exclusive Free Cloak in 1.8.9"
            checked={cloakVisible}
            onChange={setCloakVisible}
          />
        </div>
      )}

      {/* Footer Save / Reset Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#23252a] pt-5">
        <button
          type="button"
          onClick={onResetDefaults}
          className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#181a1f] px-4 py-2 text-xs font-medium text-stone-300 hover:bg-[#22252c] hover:text-white transition-colors"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Reset Defaults</span>
        </button>

        <button
          type="submit"
          disabled={saving || !validation.valid}
          className="inline-flex items-center gap-2 rounded-md bg-[#1cb5f6] px-5 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] disabled:opacity-50 transition-colors"
        >
          <Save className="h-3.5 w-3.5" />
          <span>{saving ? 'Saving...' : dirty ? 'Save Settings' : 'Saved'}</span>
        </button>
      </div>
    </form>
  );
}
