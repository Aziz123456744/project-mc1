import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ARGENTUM_MOD_JARS,
  DEFAULT_MODS,
  DEFAULT_ORNITHE_CONFIG,
  LOCKED_VERSION_ID,
  MINECRAFT_VERSIONS,
  normalizeSettingsTo189,
  getMaxSafeRamMb,
  clampRamMb,
  parseResolution,
  buildJvmArguments,
  FAST_BOOT_JVM_FLAGS,
  createOfflineAccount,
  generateOfflineUuid,
  mergeAccountLists,
  getRequiredOrnitheArtifacts,
  detectMissingOrnitheArtifacts,
  downloadMissingOrnitheLoaders,
  getDownloadPhaseBreakdown,
  validateLauncherSettings,
  evaluateMemoryEfficiency,
  formatUptime,
  filterMods,
  validateServerTile,
  type LauncherSettings,
  type VersionDownloadStatus,
} from './launcherLogic';

const baseSettings: LauncherSettings = {
  version: '1.8.9',
  account: 'AlexBuilder',
  optifine: true,
  beta: false,
  ram_mb: 3072,
  mc_path: '/home/player/.minecraft',
  java_path: '/usr/lib/jvm/java-8',
  resolution: '1280x720',
  new_gc: true,
  minimize_on_launch: true,
};

test('version catalog contains only 1.8.9', () => {
  assert.equal(LOCKED_VERSION_ID, '1.8.9');
  assert.equal(MINECRAFT_VERSIONS.length, 1);
  assert.equal(MINECRAFT_VERSIONS[0].id, '1.8.9');
});

test('normalizeSettingsTo189 forces version 1.8.9 and disables beta', () => {
  const normalized = normalizeSettingsTo189({
    ...baseSettings,
    version: '1.21.4',
    beta: true,
  });
  assert.equal(normalized.version, '1.8.9');
  assert.equal(normalized.beta, false);
});

test('clampRamMb respects 1024 MB floor and safe system RAM ceiling', () => {
  assert.equal(getMaxSafeRamMb(16384), 14592);
  assert.equal(clampRamMb(512, 16384), 1024);
  assert.equal(clampRamMb(16000, 16384), 14592);
  assert.equal(clampRamMb(3072, 16384), 3072);
});

test('parseResolution handles both compact and spaced WIDTH x HEIGHT formats', () => {
  assert.deepEqual(parseResolution('1280 x 720'), {
    valid: true,
    width: 1280,
    height: 720,
    normalized: '1280x720',
  });
  assert.equal(parseResolution('invalid').valid, false);
  assert.equal(parseResolution('320x240').valid, false);
});

test('buildJvmArguments always targets 1.8.9.jar with fast-boot JVM flags on POSIX and Windows', () => {
  const posixCmd = buildJvmArguments(baseSettings);
  assert.equal(posixCmd.javaBin, '/usr/lib/jvm/java-8/bin/java');
  assert.equal(posixCmd.clientJar, '/home/player/.minecraft/versions/1.8.9/1.8.9.jar');
  assert.deepEqual(posixCmd.args, [
    '-Xmx3072M',
    '-Xms512M',
    '-XX:+UseG1GC',
    ...FAST_BOOT_JVM_FLAGS,
    '-Djava.library.path=/home/player/.minecraft/versions/1.8.9/natives',
    '-jar',
    '/home/player/.minecraft/versions/1.8.9/1.8.9.jar',
    '--username',
    'AlexBuilder',
    '--version',
    '1.8.9',
    '--gameDir',
    '/home/player/.minecraft',
    '--assetsDir',
    '/home/player/.minecraft/assets',
    '--assetIndex',
    '1.8',
    '--width',
    '1280',
    '--height',
    '720',
  ]);

  const winCmd = buildJvmArguments({
    ...baseSettings,
    java_path: 'C:\\Program Files\\Java\\jdk-17',
    mc_path: 'C:\\Users\\Player\\AppData\\Roaming\\.minecraft',
    new_gc: false,
  });
  assert.equal(winCmd.javaBin, 'C:\\Program Files\\Java\\jdk-17\\bin\\javaw.exe');
  assert.equal(
    winCmd.clientJar,
    'C:\\Users\\Player\\AppData\\Roaming\\.minecraft\\versions\\1.8.9\\1.8.9.jar'
  );
  assert.equal(winCmd.args.includes('-XX:+UseG1GC'), false);
  assert.ok(winCmd.args.includes('-Djava.net.preferIPv4Stack=true'));
});

test('buildJvmArguments emits Ornithe 1.8.9 KnotClient classpath and fast-boot flags when enabled', () => {
  const ornitheCmd = buildJvmArguments(baseSettings, DEFAULT_ORNITHE_CONFIG);
  assert.equal(ornitheCmd.loaderLabel, 'Ornithe 0.20.1 (1.8.9)');
  assert.ok(ornitheCmd.args.includes('-Dfabric.gameVersion=1.8.9'));
  assert.ok(ornitheCmd.args.includes('-Dfabric.fixPackageAccess=true'));
  assert.ok(ornitheCmd.args.includes('-Dornithe.mappings=calamus-gen2-1.8.9'));
  assert.ok(ornitheCmd.args.includes('-Dmixin.hotSwap=false'));
  assert.ok(ornitheCmd.args.includes('--gameDir'));
  assert.ok(ornitheCmd.args.includes('--assetsDir'));
  assert.ok(ornitheCmd.args.includes('net.fabricmc.loader.impl.launch.knot.KnotClient'));
  assert.ok(
    ornitheCmd.commandLine.includes(
      '/home/player/.minecraft/libraries/net/fabricmc/fabric-loader/0.20.1/fabric-loader-0.20.1.jar:/home/player/.minecraft/libraries/net/ornithemc/calamus-intermediary-gen2/1.8.9/calamus-intermediary-gen2-1.8.9.jar:/home/player/.minecraft/versions/1.8.9/1.8.9.jar'
    )
  );
});

test('validateLauncherSettings rejects non-1.8.9 versions and invalid fields', () => {
  assert.equal(validateLauncherSettings(baseSettings, 16384).valid, true);

  const wrongVersion = validateLauncherSettings(
    { ...baseSettings, version: '1.20.1' },
    16384
  );
  assert.equal(wrongVersion.valid, false);
  assert.ok(wrongVersion.errors.version);

  const invalidFields = validateLauncherSettings(
    { ...baseSettings, account: '', mc_path: '', ram_mb: 512, resolution: 'bad' },
    16384
  );
  assert.equal(invalidFields.valid, false);
  assert.ok(invalidFields.errors.account);
  assert.ok(invalidFields.errors.mc_path);
  assert.ok(invalidFields.errors.ram_mb);
  assert.ok(invalidFields.errors.resolution);
});

test('evaluateMemoryEfficiency classifies standby, optimal, moderate, high, and exceeded tiers', () => {
  const idle = evaluateMemoryEfficiency(0, 0, 3072, false);
  assert.equal(idle.tier, 'idle');
  assert.equal(idle.usedPctOfXmx, 0);

  const optimal = evaluateMemoryEfficiency(1024, 1536, 3072, true);
  assert.equal(optimal.tier, 'optimal');
  assert.equal(optimal.usedPctOfXmx, 33);
  assert.equal(optimal.allocatedPctOfXmx, 50);

  const moderate = evaluateMemoryEfficiency(2150, 2560, 3072, true);
  assert.equal(moderate.tier, 'moderate');
  assert.equal(moderate.usedPctOfXmx, 70);

  const high = evaluateMemoryEfficiency(2765, 3072, 3072, true);
  assert.equal(high.tier, 'high');
  assert.equal(high.usedPctOfXmx, 90);

  const exceeded = evaluateMemoryEfficiency(3200, 3200, 3072, true);
  assert.equal(exceeded.tier, 'exceeded');
});

test('formatUptime formats elapsed seconds as MM:SS or HH:MM:SS', () => {
  assert.equal(formatUptime(0), '00:00');
  assert.equal(formatUptime(75), '01:15');
  assert.equal(formatUptime(3665), '01:01:05');
});

test('filterMods filters by category and search query', () => {
  const all = filterMods(DEFAULT_MODS, { category: 'All', search: '' });
  assert.equal(all.length, DEFAULT_MODS.length);

  const pvp = filterMods(DEFAULT_MODS, { category: 'PvP HUD', search: '' });
  assert.ok(pvp.length > 0);
  assert.ok(pvp.every((m) => m.category === 'PvP HUD'));

  const searchResult = filterMods(DEFAULT_MODS, { category: 'All', search: 'keystrokes' });
  assert.equal(searchResult.length, 1);
  assert.equal(searchResult[0].id, 'keystrokes-hud');
});

test('validateServerTile validates name, address, and shortCode', () => {
  assert.deepEqual(
    validateServerTile({ name: 'Lunar Practice', address: 'lunar.gg', shortCode: 'lp' }),
    {
      valid: true,
      normalized: { name: 'Lunar Practice', address: 'lunar.gg', shortCode: 'LP' },
    }
  );
  assert.equal(
    validateServerTile({ name: 'A', address: 'lunar.gg', shortCode: 'LP' }).valid,
    false
  );
  assert.equal(
    validateServerTile({ name: 'Lunar', address: 'invalidhost', shortCode: 'LP' }).valid,
    false
  );
  assert.equal(
    validateServerTile({ name: 'Lunar', address: 'lunar.gg', shortCode: 'TOOLONG' }).valid,
    false
  );
});

test('getRequiredOrnitheArtifacts includes Ornithe 1.8.9 loaders, Argentum 1.0.2, OSL, Pylon, and ForgeCompat JARs', () => {
  assert.deepEqual(
    ARGENTUM_MOD_JARS.map((j) => j.fileName),
    [
      'argentum-1.0.2.jar',
      'argentum-extras-1.0.2.jar',
      'cera-1.0.2.jar',
      'ornithe-standard-libraries-0.24.0.jar',
      'pylon-0.2.2-beta.1.jar',
      'forgecompat-1.1.4+1.8.9.jar',
    ]
  );

  const specs = getRequiredOrnitheArtifacts('/mc', DEFAULT_ORNITHE_CONFIG, true);
  const fileNames = specs.map((s) => s.fileName);
  assert.ok(fileNames.includes('1.8.9.jar'));
  assert.ok(fileNames.includes('fabric-loader-0.20.1.jar'));
  assert.ok(fileNames.includes('calamus-intermediary-gen2-1.8.9.jar'));
  assert.ok(fileNames.includes('1.8.9-ornithe.json'));
  assert.ok(fileNames.includes('argentum-1.0.2.jar'));
  assert.ok(fileNames.includes('argentum-extras-1.0.2.jar'));
  assert.ok(fileNames.includes('cera-1.0.2.jar'));
  assert.ok(fileNames.includes('ornithe-standard-libraries-0.24.0.jar'));
  assert.ok(fileNames.includes('pylon-0.2.2-beta.1.jar'));
  assert.ok(fileNames.includes('forgecompat-1.1.4+1.8.9.jar'));
});

test('downloadMissingOrnitheLoaders detects missing JARs and emits progress updates', async () => {
  const existing = new Set<string>([
    '/mc/versions/1.8.9/1.8.9.jar',
    '/mc/assets/indexes/1.8.json',
    '/mc/mods/cera-1.0.2.jar',
  ]);
  const specs = getRequiredOrnitheArtifacts('/mc', DEFAULT_ORNITHE_CONFIG, true);
  const missing = await detectMissingOrnitheArtifacts(specs, (p) => existing.has(p));
  assert.equal(missing.length, 8);

  const progressEvents: VersionDownloadStatus[] = [];
  let activeInFlight = 0;
  let maxInFlight = 0;
  const result = await downloadMissingOrnitheLoaders({
    mcPath: '/mc',
    ornithe: DEFAULT_ORNITHE_CONFIG,
    includeArgentumMods: true,
    concurrency: 3,
    existsFn: (p) => existing.has(p),
    downloadArtifact: async (spec) => {
      activeInFlight += 1;
      maxInFlight = Math.max(maxInFlight, activeInFlight);
      await new Promise((resolve) => setTimeout(resolve, 15));
      existing.add(spec.targetPath);
      activeInFlight -= 1;
    },
    onProgress: (status) => {
      progressEvents.push(status);
    },
  });

  assert.equal(result.downloadedCount, 8);
  assert.equal(result.skippedCount, 3);
  assert.ok(maxInFlight > 1, 'Expected concurrent artifact downloads');
  assert.ok(result.downloadedFiles.includes('fabric-loader-0.20.1.jar'));
  assert.ok(result.downloadedFiles.includes('argentum-1.0.2.jar'));
  assert.ok(result.downloadedFiles.includes('ornithe-standard-libraries-0.24.0.jar'));
  assert.ok(result.downloadedFiles.includes('pylon-0.2.2-beta.1.jar'));
  assert.ok(result.downloadedFiles.includes('forgecompat-1.1.4+1.8.9.jar'));
  assert.equal(progressEvents[0].state, 'downloading');
  assert.equal(progressEvents[progressEvents.length - 1].state, 'complete');
  assert.equal(progressEvents[progressEvents.length - 1].percent, 100);

  // Subsequent run skips everything
  const secondRun = await downloadMissingOrnitheLoaders({
    mcPath: '/mc',
    ornithe: DEFAULT_ORNITHE_CONFIG,
    includeArgentumMods: true,
    existsFn: (p) => existing.has(p),
    downloadArtifact: async () => {
      throw new Error('Should not download when all JARs exist');
    },
  });
  assert.equal(secondRun.downloadedCount, 0);
  assert.equal(secondRun.skippedCount, 11);
});

test('getDownloadPhaseBreakdown computes 3-stage state for fetching JARs, Ornithe loader, and Argentum mods', () => {
  const midDownload: VersionDownloadStatus = {
    state: 'downloading',
    percent: 44,
    currentArtifact: 'Ornithe Calamus Mappings 1.8.9-v2',
    completedCount: 3,
    totalCount: 9,
    artifacts: [
      { id: 'mc-189-jar', label: '1.8.9.jar', sizeLabel: '8.7 MB', status: 'done', group: 'client' },
      { id: 'mc-18-assets', label: '1.8.json', sizeLabel: '114 MB', status: 'done', group: 'client' },
      { id: 'ornithe-loader', label: 'fabric-loader', sizeLabel: '1.4 MB', status: 'done', group: 'ornithe' },
      { id: 'ornithe-calamus', label: 'calamus', sizeLabel: '0.9 MB', status: 'downloading', group: 'ornithe' },
      { id: 'ornithe-profile', label: 'profile', sizeLabel: '12 KB', status: 'pending', group: 'ornithe' },
      { id: 'argentum-core', label: 'argentum', sizeLabel: '1.8 MB', status: 'pending', group: 'argentum' },
      { id: 'forgecompat', label: 'forgecompat', sizeLabel: '510 KB', status: 'pending', group: 'argentum' },
    ],
  };

  const phases = getDownloadPhaseBreakdown(midDownload);
  assert.equal(phases.length, 3);
  assert.deepEqual(
    phases.map((p) => ({ id: p.id, state: p.state, completed: p.completed, total: p.total })),
    [
      { id: 'client', state: 'done', completed: 2, total: 2 },
      { id: 'ornithe', state: 'active', completed: 1, total: 3 },
      { id: 'argentum', state: 'pending', completed: 0, total: 2 },
    ]
  );
});

test('createOfflineAccount validates usernames, generates deterministic UUID, and merges lists', () => {
  const existing = [{ username: 'AlexBuilder', type: 'Microsoft' as const, uuid: '111' }];

  const badShort = createOfflineAccount('ab', existing);
  assert.equal(badShort.valid, false);

  const duplicate = createOfflineAccount('alexbuilder', existing);
  assert.equal(duplicate.valid, false);

  const created = createOfflineAccount('  OfflineHero  ', existing);
  assert.equal(created.valid, true);
  assert.equal(created.profile?.username, 'OfflineHero');
  assert.equal(created.profile?.type, 'Offline');
  assert.equal(created.profile?.uuid, generateOfflineUuid('OfflineHero'));

  const merged = mergeAccountLists(existing, [
    { username: 'AlexBuilder', type: 'Offline', uuid: 'dup' },
    created.profile!,
  ]);
  assert.equal(merged.length, 2);
  assert.equal(merged[0].type, 'Microsoft');
  assert.equal(merged[1].username, 'OfflineHero');
});

import {
  buildModJarEntry,
  mavenCoordToPath,
  parseServerAddress,
  toggleModJarFileName,
  validateModJarFileName,
} from './launcherLogic';

test('validateModJarFileName rejects traversal/non-jar and accepts valid mod jars', () => {
  assert.equal(validateModJarFileName('../hack.jar').sanitized, 'hack.jar');
  assert.equal(validateModJarFileName('readme.txt').valid, false);
  assert.equal(validateModJarFileName('bad name with spaces.jar').valid, false);
  assert.deepEqual(validateModJarFileName('OptiHud-1.8.9+build.2.jar'), {
    valid: true,
    sanitized: 'OptiHud-1.8.9+build.2.jar',
  });
});

test('toggleModJarFileName and buildModJarEntry handle enabled and disabled mod JARs', () => {
  assert.equal(toggleModJarFileName('custom-mod.jar', false), 'custom-mod.jar.disabled');
  assert.equal(toggleModJarFileName('custom-mod.jar.disabled', true), 'custom-mod.jar');

  const core = buildModJarEntry('argentum-1.0.2.jar', 1775007);
  assert.equal(core?.isCoreArgentum, true);
  assert.equal(core?.enabled, true);

  const disabledCustom = buildModJarEntry('my-pvp-mod.jar.disabled', 42000);
  assert.equal(disabledCustom?.isCoreArgentum, false);
  assert.equal(disabledCustom?.enabled, false);
  assert.equal(disabledCustom?.baseName, 'my-pvp-mod.jar');
});

test('parseServerAddress and mavenCoordToPath resolve host/port and Maven JAR paths', () => {
  assert.deepEqual(parseServerAddress('mc.hypixel.net'), { host: 'mc.hypixel.net', port: 25565 });
  assert.deepEqual(parseServerAddress('play.example.net:25566'), {
    host: 'play.example.net',
    port: 25566,
  });
  assert.equal(parseServerAddress('   '), null);

  assert.equal(
    mavenCoordToPath('org.ow2.asm:asm:9.10.1'),
    'org/ow2/asm/asm/9.10.1/asm-9.10.1.jar'
  );
  assert.equal(
    mavenCoordToPath('net.ornithemc:calamus-intermediary-gen2:1.8.9'),
    'net/ornithemc/calamus-intermediary-gen2/1.8.9/calamus-intermediary-gen2-1.8.9.jar'
  );
});





