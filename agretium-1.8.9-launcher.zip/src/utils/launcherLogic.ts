export interface LauncherSettings {
  version: string;
  account: string;
  optifine: boolean;
  beta: boolean;
  ram_mb: number;
  mc_path: string;
  java_path: string;
  resolution: string;
  new_gc: boolean;
  minimize_on_launch: boolean;
}

export interface LauncherPreferences {
  logRetention: 'Forever' | '30 Days' | '7 Days' | 'Session Only';
  startupBehavior: 'Do not start' | 'Start minimized' | 'Open window';
  launchOfflineWithoutPrompt: boolean;
  closeOnShutdown: boolean;
  hideJarUpdateWindow: boolean;
  shutdownWhileRunning: boolean;
  desktopNotifications: boolean;
  patchInBackground: 'Off' | 'On';
  language: 'English' | 'Español' | 'Deutsch' | 'Français';
}

export interface SystemInfo {
  total_ram_mb: number;
}

export interface MinecraftVersion {
  id: string;
  title: string;
  channel: 'release';
  releaseDate: string;
  optifineSupported: boolean;
  javaRequired: number;
  summary: string;
  highlights: string[];
}

export interface AccountProfile {
  username: string;
  type: 'Microsoft' | 'Offline';
  uuid: string;
}

export interface ServerQuickTile {
  id: string;
  name: string;
  address: string;
  shortCode: string;
  accentColor: string;
  enabled: boolean;
}

export interface NewsArticle {
  id: string;
  title: string;
  date: string;
  isNew: boolean;
  views: number;
  image: string;
  summary: string;
  body: string[];
}

export interface LaunchHistoryEntry {
  id: string;
  timestamp: string;
  version: string;
  account: string;
  ram_mb: number;
  optifine: boolean;
  resolution: string;
  command: string;
  status: 'launched' | 'failed';
  message: string;
  serverAddress?: string;
  launchDurationMs?: number;
}

export interface LaunchResponse {
  ok: boolean;
  message: string;
  command: string;
  args: string[];
  javaBin: string;
  clientJar: string;
  minimized: boolean;
  launchDurationMs?: number;
  historyEntry: LaunchHistoryEntry;
}

export type ModCategory = 'FPS & Rendering' | 'PvP HUD' | 'Utility';

export interface AgretiumMod {
  id: string;
  name: string;
  category: ModCategory;
  description: string;
  enabled: boolean;
}

export interface CloakCosmetic {
  id: string;
  name: string;
  subtitle: string;
  primaryColor: string;
  secondaryColor: string;
  pattern: 'emblem' | 'chevron' | 'horizon' | 'crest' | 'none';
}

export interface OrnitheConfig {
  enabled: boolean;
  loaderVersion: string;
  calamusVersion: string;
}

export interface LauncherExtras {
  servers: ServerQuickTile[];
  mods: AgretiumMod[];
  equippedCloakId: string;
  preferences: LauncherPreferences;
  ornithe: OrnitheConfig;
  accounts?: AccountProfile[];
}

export interface PreflightStatus {
  javaOk: boolean;
  jarOk: boolean;
  assetsOk: boolean;
  ornitheOk: boolean;
  argentumOk: boolean;
  needsDownload: boolean;
  missingArtifacts: string[];
  javaBin: string;
  clientJar: string;
  checkedAt: string;
}

export type DownloadPhaseGroup = 'client' | 'ornithe' | 'argentum';

export interface VersionDownloadArtifact {
  id: string;
  label: string;
  fileName?: string;
  sizeLabel: string;
  status: 'pending' | 'downloading' | 'done';
  group?: DownloadPhaseGroup;
}

export interface VersionDownloadStatus {
  state: 'idle' | 'downloading' | 'complete' | 'error';
  percent: number;
  currentArtifact: string | null;
  completedCount: number;
  totalCount: number;
  artifacts: VersionDownloadArtifact[];
  error?: string;
}

export interface JvmLogEntry {
  id: string;
  time: string;
  level: 'INFO' | 'WARN' | 'DEBUG';
  thread: string;
  message: string;
}

export interface FriendPresence {
  id: string;
  username: string;
  status: 'in-game' | 'online';
  serverName?: string;
  serverAddress?: string;
  activity: string;
}

export const LOCKED_VERSION_ID = '1.8.9';

export const ARGENTUM_RELEASES_URL = 'https://github.com/QuicksilverMC/Argentum/releases';
export const ARGENTUM_RELEASE_TAG = '1.0.2';

export interface ArgentumModJar {
  id: string;
  name: string;
  fileName: string;
  version: string;
  sizeLabel: string;
  downloadUrl: string;
  description: string;
}

export const ARGENTUM_MOD_JARS: ArgentumModJar[] = [
  {
    id: 'argentum-core',
    name: 'Agretium (Argentum)',
    fileName: 'argentum-1.0.2.jar',
    version: ARGENTUM_RELEASE_TAG,
    sizeLabel: '1.8 MB',
    downloadUrl:
      'https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/argentum-1.0.2.jar',
    description: 'Core 1.8.9 Ornithe rendering, chunk meshing, and lighting optimization mod.',
  },
  {
    id: 'argentum-extras',
    name: 'Agretium Extras (Argentum Extras)',
    fileName: 'argentum-extras-1.0.2.jar',
    version: ARGENTUM_RELEASE_TAG,
    sizeLabel: '55 KB',
    downloadUrl:
      'https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/argentum-extras-1.0.2.jar',
    description: 'Extended visual tweaks, dynamic light enhancements, and quality-of-life options.',
  },
  {
    id: 'cera',
    name: 'Cera',
    fileName: 'cera-1.0.2.jar',
    version: ARGENTUM_RELEASE_TAG,
    sizeLabel: '513 KB',
    downloadUrl:
      'https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/cera-1.0.2.jar',
    description: 'MCPatcher & OptiFine resource pack extensions companion mod for Argentum.',
  },
  {
    id: 'osl',
    name: 'Ornithe Standard Libraries',
    fileName: 'ornithe-standard-libraries-0.24.0.jar',
    version: '0.24.0',
    sizeLabel: '6.2 MB',
    downloadUrl:
      'https://cdn.modrinth.com/data/EHGtwpJv/versions/TzBDamVN/ornithe-standard-libraries-0.24.0.jar',
    description: 'Core Ornithe API modules (osl-core & osl-resource-loader) required by Cera.',
  },
  {
    id: 'pylon',
    name: 'Pylon (LWJGL3 / Java 25 Bridge)',
    fileName: 'pylon-0.2.2-beta.1.jar',
    version: '0.2.2-beta.1',
    sizeLabel: '1.1 MB',
    downloadUrl:
      'https://github.com/Polyfrost/pylon/releases/download/0.2.2-beta.1/pylon-0.2.2-beta.1.jar',
    description: 'Modern LWJGL3/SDL3 windowing and Java 25 runtime bridge required by ForgeCompat.',
  },
  {
    id: 'forgecompat',
    name: 'ForgeCompat',
    fileName: 'forgecompat-1.1.4+1.8.9.jar',
    version: '1.1.4+1.8.9',
    sizeLabel: '690 KB',
    downloadUrl:
      'https://github.com/Polyfrost/ForgeCompat/releases/download/v1.1.4/forgecompat-1.1.4%2B1.8.9.jar',
    description: 'Ornithe Forge compatibility bridge enabling 1.8.9 Forge-style mods alongside Argentum.',
  },
];

export const DEFAULT_ORNITHE_CONFIG: OrnitheConfig = {
  enabled: true,
  loaderVersion: '0.20.1',
  calamusVersion: '1.8.9',
};

export const MINECRAFT_VERSIONS: MinecraftVersion[] = [
  {
    id: '1.8.9',
    title: 'Minecraft 1.8.9 · Combat & PvP Edition',
    channel: 'release',
    releaseDate: '2015-12-09',
    optifineSupported: true,
    javaRequired: 25,
    summary:
      'Dedicated 1.8.9 Ornithe Gen2 runtime tuned for classic combat mechanics, Argentum rendering, and low-latency multiplayer servers.',
    highlights: [
      'Exclusive 1.8.9 client profile with classic hit registration and animations',
      'Built-in Ornithe 0.20.1 + Argentum 1.0.2 + ForgeCompat support for custom .jar mods',
      'Fast server quick-join tiles and customizable JVM garbage collection',
    ],
  },
];

export const DEFAULT_ACCOUNTS: AccountProfile[] = [
  {
    username: 'AlexBuilder',
    type: 'Microsoft',
    uuid: '8667ba71-b85a-4004-af54-457a9734eed7',
  },
  {
    username: 'RedstoneLab',
    type: 'Microsoft',
    uuid: '069a79f4-44e9-4726-a5be-fca90e38aaf5',
  },
  {
    username: 'LocalDevPlayer',
    type: 'Offline',
    uuid: '00000000-0000-3000-8000-000000000001',
  },
];

export const DEFAULT_SERVER_TILES: ServerQuickTile[] = [
  {
    id: 'hypixel',
    name: 'Hypixel',
    address: 'mc.hypixel.net',
    shortCode: 'H',
    accentColor: '#eab308',
    enabled: true,
  },
  {
    id: 'minemen',
    name: 'Minemen Club',
    address: 'na.minemen.club',
    shortCode: 'MMC',
    accentColor: '#ec4899',
    enabled: true,
  },
  {
    id: 'skyblock',
    name: 'SkyLands',
    address: 'play.skylands.gg',
    shortCode: 'S',
    accentColor: '#38bdf8',
    enabled: true,
  },
  {
    id: 'pvpclub',
    name: 'PvP Club',
    address: 'pvp.club',
    shortCode: 'PVP',
    accentColor: '#f8fafc',
    enabled: true,
  },
  {
    id: 'bedwars',
    name: 'BedWars Practice',
    address: 'bedwarspractice.club',
    shortCode: 'BW',
    accentColor: '#a855f7',
    enabled: true,
  },
  {
    id: 'tubnet',
    name: 'TubNet Arena',
    address: 'play.tubnet.gg',
    shortCode: 'T',
    accentColor: '#3b82f6',
    enabled: true,
  },
];

export const DEFAULT_MODS: AgretiumMod[] = [
  {
    id: 'agretium-fps',
    name: 'Agretium FPS Boost',
    category: 'FPS & Rendering',
    description: 'Fast math, smart entity culling, and smooth chunk meshing for 1.8.9.',
    enabled: true,
  },
  {
    id: 'toggle-sprint',
    name: 'ToggleSprint / Sneak',
    category: 'PvP HUD',
    description: 'Maintains sprint state across hits and displays an unobtrusive HUD state.',
    enabled: true,
  },
  {
    id: 'keystrokes-hud',
    name: 'Keystrokes HUD',
    category: 'PvP HUD',
    description: 'Live WASD, LMB/RMB, and spacebar overlay with customizable click rate.',
    enabled: true,
  },
  {
    id: 'cps-ping',
    name: 'CPS & Ping Counter',
    category: 'PvP HUD',
    description: 'Tracks left/right clicks per second and real-time server latency.',
    enabled: true,
  },
  {
    id: 'old-animations',
    name: '1.7 Old Animations',
    category: 'FPS & Rendering',
    description: 'Classic block-hitting, rod, bow, and armor glint animations for 1.8.9.',
    enabled: true,
  },
  {
    id: 'potion-status',
    name: 'Potion Status HUD',
    category: 'Utility',
    description: 'Displays active potion timers without opening the inventory screen.',
    enabled: false,
  },
  {
    id: 'coords-biome',
    name: 'Coordinates & Biome',
    category: 'Utility',
    description: 'Compact XYZ coordinates, cardinal direction, and current biome readout.',
    enabled: true,
  },
  {
    id: 'hitboxes-freelook',
    name: 'Hitboxes & Freelook',
    category: 'Utility',
    description: 'Crisp F3+B entity hitboxes and 360-degree third-person camera orbit.',
    enabled: false,
  },
];

export const CLOAK_CATALOG: CloakCosmetic[] = [
  {
    id: 'agretium-gold',
    name: 'Agretium Gold Cloak',
    subtitle: 'Signature amber voxel crest with dark obsidian trim',
    primaryColor: '#eab308',
    secondaryColor: '#292114',
    pattern: 'emblem',
  },
  {
    id: 'cobalt-wave',
    name: 'Cobalt Horizon Cloak',
    subtitle: 'Sky-cyan chevron weave tailored for Agretium 1.8.9',
    primaryColor: '#1cb5f6',
    secondaryColor: '#112230',
    pattern: 'chevron',
  },
  {
    id: 'obsidian-core',
    name: 'Obsidian Core Cloak',
    subtitle: 'Minimalist slate gradient with ice-blue horizon band',
    primaryColor: '#38bdf8',
    secondaryColor: '#17191f',
    pattern: 'horizon',
  },
  {
    id: 'emerald-crest',
    name: 'Emerald Crest Cloak',
    subtitle: 'Forest emerald banner with forged steel border',
    primaryColor: '#10b981',
    secondaryColor: '#12241f',
    pattern: 'crest',
  },
  {
    id: 'none',
    name: 'No Cloak Equipped',
    subtitle: 'Use vanilla skin cape slot only',
    primaryColor: '#3f434c',
    secondaryColor: '#181a1f',
    pattern: 'none',
  },
];

export const DEFAULT_FRIENDS: FriendPresence[] = [
  {
    id: 'f-1',
    username: 'VexedKnight',
    status: 'in-game',
    serverName: 'Hypixel',
    serverAddress: 'mc.hypixel.net',
    activity: 'BedWars Doubles · 1.8.9',
  },
  {
    id: 'f-2',
    username: 'KiraPvP',
    status: 'in-game',
    serverName: 'Minemen Club',
    serverAddress: 'na.minemen.club',
    activity: 'NoDebuff Ranked · 1.8.9',
  },
  {
    id: 'f-3',
    username: 'NetherForge',
    status: 'online',
    activity: 'Idle in Launcher 1.8.9',
  },
  {
    id: 'f-4',
    username: 'PixelStrafe',
    status: 'in-game',
    serverName: 'BedWars Practice',
    serverAddress: 'bedwarspractice.club',
    activity: 'Bridging Practice · 1.8.9',
  },
];

export const LAUNCHER_NEWS: NewsArticle[] = [
  {
    id: 'cloak-drop',
    title: 'Exclusive Free Cloak',
    date: 'January 8, 2025',
    isNew: true,
    views: 1954,
    image: '/assets/images/hero_voxel_landscape_1794735515436.jpg',
    summary:
      'Equip the golden voxel cloak on 1.8.9 through your active profile cosmetics panel.',
    body: [
      'Players launching Minecraft 1.8.9 can activate an exclusive animated cloak directly inside the Cosmetics section.',
      'Cosmetics render seamlessly alongside Agretium with zero frame-time penalty.',
    ],
  },
  {
    id: 'social-update',
    title: 'The Social Update',
    date: 'November 4, 2024',
    isNew: true,
    views: 1826,
    image: '/assets/images/hero_nether_update_1794735516309.jpg',
    summary:
      'Integrated party invites, friend presence indicators, and custom server quick-join tiles.',
    body: [
      'Pin your favorite 1.8.9 PvP and minigame servers directly beneath the Play button for one-click launching.',
      'Use the right utility bar to view friend online status and recent launch notifications.',
    ],
  },
  {
    id: 'client-189-agretium',
    title: '1.8.9 Performance Tuning',
    date: 'October 11, 2024',
    isNew: true,
    views: 2125,
    image: '/assets/images/hero_voxel_landscape_1794735515436.jpg',
    summary:
      'Tuned G1GC memory flags and chunk meshing presets specifically for 1.8.9.',
    body: [
      'Enable G1GC in Game Settings to stabilize frame times during high-entity BedWars and SkyWars matches.',
      'Recommended heap allocation is 3072 MB – 4096 MB for 1.8.9 texture packs.',
    ],
  },
  {
    id: 'launcher-reloaded',
    title: 'Launcher: Reloaded',
    date: 'August 9, 2024',
    isNew: false,
    views: 1581,
    image: '/assets/images/hero_nether_update_1794735516309.jpg',
    summary:
      'Redesigned dark workspace with persistent JSON profiles, folder browser, and JVM diagnostics.',
    body: [
      'All launcher settings are saved automatically to launcher_config.json and validated before spawning Java.',
      'Inspect generated JVM arguments anytime from the Debug tab inside Settings.',
    ],
  },
];

export const DEFAULT_PREFERENCES: LauncherPreferences = {
  logRetention: 'Forever',
  startupBehavior: 'Do not start',
  launchOfflineWithoutPrompt: true,
  closeOnShutdown: false,
  hideJarUpdateWindow: false,
  shutdownWhileRunning: false,
  desktopNotifications: true,
  patchInBackground: 'Off',
  language: 'English',
};

export const DEFAULT_EXTRAS: LauncherExtras = {
  servers: DEFAULT_SERVER_TILES,
  mods: DEFAULT_MODS,
  equippedCloakId: 'agretium-gold',
  preferences: DEFAULT_PREFERENCES,
  ornithe: DEFAULT_ORNITHE_CONFIG,
  accounts: DEFAULT_ACCOUNTS,
};

export const RESOLUTION_PRESETS = [
  { label: '1280 x 720', value: '1280x720' },
  { label: '1600 x 900', value: '1600x900' },
  { label: '1920 x 1080', value: '1920x1080' },
  { label: '2560 x 1440', value: '2560x1440' },
  { label: '3840 x 2160', value: '3840x2160' },
];

export function normalizeSettingsTo189(settings: LauncherSettings): LauncherSettings {
  return {
    ...settings,
    version: LOCKED_VERSION_ID,
    beta: false,
  };
}

export function getMaxSafeRamMb(totalRamMb: number): number {
  if (!Number.isFinite(totalRamMb) || totalRamMb <= 1024) {
    return 1024;
  }
  const maxMb = Math.floor((totalRamMb * 0.9) / 256) * 256;
  return Math.max(2048, Math.min(totalRamMb, maxMb));
}

export function clampRamMb(ramMb: number, totalRamMb: number): number {
  const maxSafe = getMaxSafeRamMb(totalRamMb);
  const clamped = Math.max(1024, Math.min(maxSafe, ramMb));
  return Math.round(clamped / 256) * 256;
}

export interface ParsedResolution {
  valid: boolean;
  width: number;
  height: number;
  normalized: string;
  error?: string;
}

export function parseResolution(resolution: string): ParsedResolution {
  const match = /^(\d{3,4})\s*x\s*(\d{3,4})$/i.exec(resolution.trim());
  if (!match) {
    return {
      valid: false,
      width: 0,
      height: 0,
      normalized: '',
      error: 'Resolution must use WIDTHxHEIGHT format (for example, 1280x720).',
    };
  }
  const width = Number(match[1]);
  const height = Number(match[2]);
  if (width < 640 || height < 480 || width > 7680 || height > 4320) {
    return {
      valid: false,
      width,
      height,
      normalized: '',
      error: 'Resolution must be between 640x480 and 7680x4320.',
    };
  }
  return { valid: true, width, height, normalized: `${width}x${height}` };
}

export function detectPathStyle(pathStr: string): 'windows' | 'posix' {
  if (/^[A-Za-z]:\\/.test(pathStr) || pathStr.includes('\\')) {
    return 'windows';
  }
  return 'posix';
}

export function joinPlatformPath(base: string, ...segments: string[]): string {
  const style = detectPathStyle(base);
  const sep = style === 'windows' ? '\\' : '/';
  const cleanBase = base.replace(/[\\/]+$/, '');
  const cleanSegs = segments.map((s) => s.replace(/^[\\/]+|[\\/]+$/g, ''));
  return [cleanBase, ...cleanSegs].filter(Boolean).join(sep);
}

export interface JvmCommandSpec {
  javaBin: string;
  clientJar: string;
  ornitheLoaderJar: string;
  calamusJar: string;
  ornitheProfileJson: string;
  args: string[];
  commandLine: string;
  loaderLabel: string;
}

export const FAST_BOOT_JVM_FLAGS = [
  '-XX:+ParallelRefProcEnabled',
  '-XX:MaxGCPauseMillis=50',
  '-XX:+DisableExplicitGC',
  '-Djava.net.preferIPv4Stack=true',
] as const;

export function buildJvmArguments(
  settings: LauncherSettings,
  ornithe?: OrnitheConfig,
  serverAddress?: string
): JvmCommandSpec {
  const normalized = normalizeSettingsTo189(settings);
  const javaStyle = detectPathStyle(normalized.java_path);
  const mcStyle = detectPathStyle(normalized.mc_path);
  const javaExe = javaStyle === 'windows' ? 'javaw.exe' : 'java';
  const cpSep = mcStyle === 'windows' ? ';' : ':';
  const javaBin = joinPlatformPath(normalized.java_path, 'bin', javaExe);
  const clientJar = joinPlatformPath(
    normalized.mc_path,
    'versions',
    LOCKED_VERSION_ID,
    `${LOCKED_VERSION_ID}.jar`
  );

  const loaderVer = ornithe?.loaderVersion ?? DEFAULT_ORNITHE_CONFIG.loaderVersion;
  const calamusVer = ornithe?.calamusVersion ?? DEFAULT_ORNITHE_CONFIG.calamusVersion;

  const ornitheLoaderJar = joinPlatformPath(
    normalized.mc_path,
    'libraries',
    'net',
    'fabricmc',
    'fabric-loader',
    loaderVer,
    `fabric-loader-${loaderVer}.jar`
  );
  const calamusJar = joinPlatformPath(
    normalized.mc_path,
    'libraries',
    'net',
    'ornithemc',
    'calamus-intermediary-gen2',
    calamusVer,
    `calamus-intermediary-gen2-${calamusVer}.jar`
  );
  const ornitheProfileJson = joinPlatformPath(
    normalized.mc_path,
    'versions',
    `${LOCKED_VERSION_ID}-ornithe`,
    `${LOCKED_VERSION_ID}-ornithe.json`
  );
  const nativesDir = joinPlatformPath(
    normalized.mc_path,
    'versions',
    LOCKED_VERSION_ID,
    'natives'
  );
  const assetsDir = joinPlatformPath(normalized.mc_path, 'assets');
  const parsedRes = parseResolution(normalized.resolution);
  const resWidth = parsedRes.valid ? parsedRes.width : 1280;
  const resHeight = parsedRes.valid ? parsedRes.height : 720;

  const args: string[] = [`-Xmx${normalized.ram_mb}M`, '-Xms512M'];

  if (normalized.new_gc) {
    args.push('-XX:+UseG1GC');
  }

  args.push(...FAST_BOOT_JVM_FLAGS);

  let loaderLabel = 'Vanilla 1.8.9';
  if (ornithe?.enabled) {
    loaderLabel = `Ornithe ${loaderVer} (1.8.9)`;
    args.push(
      `-Djava.library.path=${nativesDir}`,
      '-Dfabric.fixPackageAccess=true',
      `-Dfabric.gameVersion=${LOCKED_VERSION_ID}`,
      `-Dfabric.loaderVersion=${loaderVer}`,
      `-Dornithe.mappings=calamus-gen2-${calamusVer}`,
      '-Dmixin.hotSwap=false',
      '-cp',
      [ornitheLoaderJar, calamusJar, clientJar].join(cpSep),
      'net.fabricmc.loader.impl.launch.knot.KnotClient',
      '--username',
      normalized.account,
      '--version',
      `${LOCKED_VERSION_ID}-ornithe`,
      '--gameDir',
      normalized.mc_path,
      '--assetsDir',
      assetsDir,
      '--assetIndex',
      '1.8',
      '--uuid',
      generateOfflineUuid(normalized.account).replace(/-/g, ''),
      '--accessToken',
      '0',
      '--userType',
      'legacy',
      '--width',
      String(resWidth),
      '--height',
      String(resHeight)
    );
  } else {
    args.push(
      `-Djava.library.path=${nativesDir}`,
      '-jar',
      clientJar,
      '--username',
      normalized.account,
      '--version',
      LOCKED_VERSION_ID,
      '--gameDir',
      normalized.mc_path,
      '--assetsDir',
      assetsDir,
      '--assetIndex',
      '1.8',
      '--width',
      String(resWidth),
      '--height',
      String(resHeight)
    );
  }

  const parsedServer = parseServerAddress(serverAddress);
  if (parsedServer) {
    args.push('--server', parsedServer.host, '--port', String(parsedServer.port));
  }

  const quoteIfNeeded = (val: string) => (/\s/.test(val) ? `"${val}"` : val);
  const commandLine = [quoteIfNeeded(javaBin), ...args.map(quoteIfNeeded)].join(' ');

  return {
    javaBin,
    clientJar,
    ornitheLoaderJar,
    calamusJar,
    ornitheProfileJson,
    args,
    commandLine,
    loaderLabel,
  };
}

export interface OrnitheArtifactSpec {
  id: string;
  label: string;
  fileName: string;
  targetPath: string;
  sourceUrl: string;
  sizeLabel: string;
  group: 'client' | 'ornithe' | 'argentum';
}

export function getRequiredOrnitheArtifacts(
  mcPath: string,
  ornithe: OrnitheConfig = DEFAULT_ORNITHE_CONFIG,
  includeArgentumMods = true
): OrnitheArtifactSpec[] {
  const loaderVer = ornithe.loaderVersion || DEFAULT_ORNITHE_CONFIG.loaderVersion;
  const calamusVer = ornithe.calamusVersion || DEFAULT_ORNITHE_CONFIG.calamusVersion;

  const clientJar = joinPlatformPath(
    mcPath,
    'versions',
    LOCKED_VERSION_ID,
    `${LOCKED_VERSION_ID}.jar`
  );
  const assetsIndex = joinPlatformPath(mcPath, 'assets', 'indexes', '1.8.json');

  const specs: OrnitheArtifactSpec[] = [
    {
      id: 'mc-189-jar',
      label: 'Minecraft 1.8.9 Client JAR',
      fileName: '1.8.9.jar',
      targetPath: clientJar,
      sourceUrl: 'https://piston-data.mojang.com/v1/objects/3870888a6c3d349d3771a3e9d16c9bf5e076b908/client.jar',
      sizeLabel: '8.7 MB',
      group: 'client',
    },
    {
      id: 'mc-18-assets',
      label: '1.8 Asset Index & Sound Resources',
      fileName: '1.8.json',
      targetPath: assetsIndex,
      sourceUrl: 'https://launchermeta.mojang.com/v1/packages/f6ad102bcaa53b1a58358f16e376d548d44933ec/1.8.json',
      sizeLabel: '114.2 MB',
      group: 'client',
    },
  ];

  if (ornithe.enabled) {
    specs.push(
      {
        id: 'ornithe-loader',
        label: `Ornithe Fabric Loader ${loaderVer}`,
        fileName: `fabric-loader-${loaderVer}.jar`,
        targetPath: joinPlatformPath(
          mcPath,
          'libraries',
          'net',
          'fabricmc',
          'fabric-loader',
          loaderVer,
          `fabric-loader-${loaderVer}.jar`
        ),
        sourceUrl: `https://maven.fabricmc.net/net/fabricmc/fabric-loader/${loaderVer}/fabric-loader-${loaderVer}.jar`,
        sizeLabel: '1.6 MB',
        group: 'ornithe',
      },
      {
        id: 'ornithe-calamus',
        label: `Ornithe Calamus Gen2 Mappings ${calamusVer}`,
        fileName: `calamus-intermediary-gen2-${calamusVer}.jar`,
        targetPath: joinPlatformPath(
          mcPath,
          'libraries',
          'net',
          'ornithemc',
          'calamus-intermediary-gen2',
          calamusVer,
          `calamus-intermediary-gen2-${calamusVer}.jar`
        ),
        sourceUrl: `https://maven.ornithemc.net/releases/net/ornithemc/calamus-intermediary-gen2/${calamusVer}/calamus-intermediary-gen2-${calamusVer}.jar`,
        sizeLabel: '0.9 MB',
        group: 'ornithe',
      },
      {
        id: 'ornithe-profile',
        label: '1.8.9-ornithe Launch Profile',
        fileName: '1.8.9-ornithe.json',
        targetPath: joinPlatformPath(
          mcPath,
          'versions',
          `${LOCKED_VERSION_ID}-ornithe`,
          `${LOCKED_VERSION_ID}-ornithe.json`
        ),
        sourceUrl: `https://meta.ornithemc.net/v3/versions/gen2/fabric-loader/${LOCKED_VERSION_ID}/${loaderVer}/profile/json`,
        sizeLabel: '12 KB',
        group: 'ornithe',
      }
    );
  }

  if (includeArgentumMods) {
    for (const jar of ARGENTUM_MOD_JARS) {
      specs.push({
        id: jar.id,
        label: `${jar.name} (${jar.fileName})`,
        fileName: jar.fileName,
        targetPath: joinPlatformPath(mcPath, 'mods', jar.fileName),
        sourceUrl: jar.downloadUrl,
        sizeLabel: jar.sizeLabel,
        group: 'argentum',
      });
    }
  }

  return specs;
}

export async function detectMissingOrnitheArtifacts(
  specs: OrnitheArtifactSpec[],
  existsFn: (targetPath: string) => boolean | Promise<boolean>
): Promise<OrnitheArtifactSpec[]> {
  const missing: OrnitheArtifactSpec[] = [];
  for (const spec of specs) {
    const present = await existsFn(spec.targetPath);
    if (!present) {
      missing.push(spec);
    }
  }
  return missing;
}

export interface OrnitheDownloadManagerOptions {
  mcPath: string;
  ornithe?: OrnitheConfig;
  includeArgentumMods?: boolean;
  concurrency?: number;
  existsFn: (targetPath: string) => boolean | Promise<boolean>;
  downloadArtifact: (spec: OrnitheArtifactSpec) => Promise<void>;
  onProgress?: (status: VersionDownloadStatus) => void;
}

export interface OrnitheDownloadManagerResult {
  downloadedCount: number;
  skippedCount: number;
  downloadedFiles: string[];
  status: VersionDownloadStatus;
}

/**
 * Download manager for Ornithe 1.8.9 loader JARs, 1.8.9 client files, and Argentum/ForgeCompat mods.
 * Detects missing artifacts in the game directory and downloads only missing files concurrently with progress updates.
 */
export async function downloadMissingOrnitheLoaders(
  options: OrnitheDownloadManagerOptions
): Promise<OrnitheDownloadManagerResult> {
  const ornithe = options.ornithe ?? DEFAULT_ORNITHE_CONFIG;
  const includeMods = options.includeArgentumMods ?? true;
  const allSpecs = getRequiredOrnitheArtifacts(options.mcPath, ornithe, includeMods);
  const missingSpecs = await detectMissingOrnitheArtifacts(allSpecs, options.existsFn);
  const skippedCount = allSpecs.length - missingSpecs.length;

  if (missingSpecs.length === 0) {
    const completeStatus: VersionDownloadStatus = {
      state: 'complete',
      percent: 100,
      currentArtifact: null,
      completedCount: 0,
      totalCount: 0,
      artifacts: [],
    };
    options.onProgress?.(completeStatus);
    return {
      downloadedCount: 0,
      skippedCount,
      downloadedFiles: [],
      status: completeStatus,
    };
  }

  const concurrency = Math.max(1, Math.min(missingSpecs.length, options.concurrency ?? 3));
  const statuses: Array<VersionDownloadArtifact['status']> = missingSpecs.map((_, idx) =>
    idx < concurrency ? 'downloading' : 'pending'
  );
  const artifacts: VersionDownloadArtifact[] = missingSpecs.map((spec, idx) => ({
    id: spec.id,
    label: spec.label,
    fileName: spec.fileName,
    sizeLabel: spec.sizeLabel,
    status: statuses[idx],
    group: spec.group,
  }));

  const emit = (
    state: VersionDownloadStatus['state'],
    completedCount: number,
    activeIndex: number | null,
    error?: string
  ): VersionDownloadStatus => {
    const totalCount = missingSpecs.length;
    const percent =
      state === 'complete'
        ? 100
        : completedCount === 0
        ? 5
        : Math.round((completedCount / totalCount) * 100);
    const snapshot: VersionDownloadStatus = {
      state,
      percent,
      currentArtifact:
        state === 'downloading' && activeIndex !== null && missingSpecs[activeIndex]
          ? missingSpecs[activeIndex].label
          : null,
      completedCount,
      totalCount,
      artifacts: artifacts.map((item, idx) => ({
        ...item,
        status: statuses[idx],
      })),
      ...(error ? { error } : {}),
    };
    options.onProgress?.(snapshot);
    return snapshot;
  };

  let completedCount = 0;
  let nextIndex = 0;
  let currentStatus = emit('downloading', 0, 0);
  const downloadedFiles: string[] = [];

  try {
    const worker = async () => {
      while (true) {
        const idx = nextIndex;
        if (idx >= missingSpecs.length) break;
        nextIndex += 1;
        statuses[idx] = 'downloading';
        currentStatus = emit('downloading', completedCount, idx);

        const spec = missingSpecs[idx];
        await options.downloadArtifact(spec);
        statuses[idx] = 'done';
        downloadedFiles.push(spec.fileName);
        completedCount += 1;

        const nextActive = statuses.findIndex((st) => st === 'downloading');
        currentStatus = emit(
          completedCount >= missingSpecs.length ? 'complete' : 'downloading',
          completedCount,
          nextActive >= 0 ? nextActive : null
        );
      }
    };

    await Promise.all(Array.from({ length: concurrency }, () => worker()));

    return {
      downloadedCount: downloadedFiles.length,
      skippedCount,
      downloadedFiles,
      status: currentStatus,
    };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Failed to download Ornithe 1.8.9 loader files';
    emit('error', downloadedFiles.length, null, message);
    throw err;
  }
}

export interface DownloadStageSummary {
  id: DownloadPhaseGroup;
  label: string;
  completed: number;
  total: number;
  percent: number;
  state: 'pending' | 'active' | 'done' | 'skipped';
}

const PHASE_DEFINITIONS: Array<{ id: DownloadPhaseGroup; label: string }> = [
  { id: 'client', label: 'Fetching 1.8.9 JARs' },
  { id: 'ornithe', label: 'Ornithe Loader' },
  { id: 'argentum', label: 'Argentum & ForgeCompat' },
];

function inferArtifactGroup(artifact: VersionDownloadArtifact): DownloadPhaseGroup {
  if (artifact.group) return artifact.group;
  if (artifact.id.startsWith('ornithe-')) return 'ornithe';
  if (
    artifact.id.startsWith('argentum') ||
    artifact.id === 'cera' ||
    artifact.id === 'forgecompat'
  ) {
    return 'argentum';
  }
  return 'client';
}

export function getDownloadPhaseBreakdown(
  status: VersionDownloadStatus | null | undefined
): DownloadStageSummary[] {
  const artifacts = status?.artifacts ?? [];
  return PHASE_DEFINITIONS.map((def) => {
    const matching = artifacts.filter((art) => inferArtifactGroup(art) === def.id);
    if (matching.length === 0) {
      return {
        id: def.id,
        label: def.label,
        completed: 0,
        total: 0,
        percent: status?.state === 'complete' ? 100 : 0,
        state: status?.state === 'complete' ? 'done' : 'skipped',
      };
    }
    const completed = matching.filter((art) => art.status === 'done').length;
    const hasActive = matching.some((art) => art.status === 'downloading');
    const allDone = completed === matching.length;
    const state: DownloadStageSummary['state'] = allDone
      ? 'done'
      : hasActive || completed > 0
      ? 'active'
      : 'pending';
    return {
      id: def.id,
      label: def.label,
      completed,
      total: matching.length,
      percent: Math.round((completed / matching.length) * 100),
      state,
    };
  });
}

export interface ValidationResult {
  valid: boolean;
  errors: Partial<Record<keyof LauncherSettings, string>>;
}

export function validateLauncherSettings(
  settings: LauncherSettings,
  totalRamMb: number
): ValidationResult {
  const errors: Partial<Record<keyof LauncherSettings, string>> = {};

  if (settings.version.trim() !== LOCKED_VERSION_ID) {
    errors.version = `Only Minecraft ${LOCKED_VERSION_ID} is supported.`;
  }
  if (!settings.account.trim()) {
    errors.account = 'Account username cannot be empty.';
  }
  if (!settings.mc_path.trim()) {
    errors.mc_path = 'Minecraft Path is required.';
  }
  if (!settings.java_path.trim()) {
    errors.java_path = 'Java Path is required.';
  }
  const maxSafe = getMaxSafeRamMb(totalRamMb);
  if (!Number.isFinite(settings.ram_mb) || settings.ram_mb < 1024 || settings.ram_mb > maxSafe) {
    errors.ram_mb = `RAM allocation must be between 1024 MB and ${maxSafe} MB.`;
  }
  const res = parseResolution(settings.resolution);
  if (!res.valid) {
    errors.resolution = res.error;
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function formatRamGb(ramMb: number): string {
  return `${(ramMb / 1024).toFixed(1)} GB`;
}

export interface JvmStatusSnapshot {
  running: boolean;
  pid: number | null;
  version: string;
  xmx_mb: number;
  xms_mb: number;
  allocated_mb: number;
  used_mb: number;
  gc_algorithm: string;
  xmx_flag: string;
  xmx_verified: boolean;
  host_total_ram_mb: number;
  host_free_ram_mb: number;
  uptime_seconds: number;
  gc_collections: number;
  timestamp: string;
  logs: JvmLogEntry[];
}

export type MemoryEfficiencyTier = 'idle' | 'optimal' | 'moderate' | 'high' | 'exceeded';

export interface MemoryEfficiencyReport {
  usedPctOfXmx: number;
  allocatedPctOfXmx: number;
  headroomMb: number;
  tier: MemoryEfficiencyTier;
  label: string;
  guidance: string;
}

export function evaluateMemoryEfficiency(
  usedMb: number,
  allocatedMb: number,
  xmxMb: number,
  running: boolean
): MemoryEfficiencyReport {
  const safeXmx = Math.max(1, xmxMb);
  if (!running || allocatedMb <= 0) {
    return {
      usedPctOfXmx: 0,
      allocatedPctOfXmx: 0,
      headroomMb: safeXmx,
      tier: 'idle',
      label: 'Standby',
      guidance: `Launch Minecraft 1.8.9 to monitor live heap usage against -Xmx${safeXmx}M.`,
    };
  }

  const usedPctOfXmx = Math.min(100, Math.round((usedMb / safeXmx) * 100));
  const allocatedPctOfXmx = Math.min(100, Math.round((allocatedMb / safeXmx) * 100));
  const headroomMb = Math.max(0, safeXmx - usedMb);

  if (allocatedMb > safeXmx || usedMb > safeXmx) {
    return {
      usedPctOfXmx: Math.round((usedMb / safeXmx) * 100),
      allocatedPctOfXmx: Math.round((allocatedMb / safeXmx) * 100),
      headroomMb: 0,
      tier: 'exceeded',
      label: 'Ceiling Exceeded',
      guidance: `Heap exceeded -Xmx${safeXmx}M limit. Increase Allocate RAM in Game settings.`,
    };
  }

  if (usedPctOfXmx >= 85) {
    return {
      usedPctOfXmx,
      allocatedPctOfXmx,
      headroomMb,
      tier: 'high',
      label: 'High Heap Pressure',
      guidance: `Using ${usedPctOfXmx}% of -Xmx${safeXmx}M. Consider raising RAM allocation or triggering GC.`,
    };
  }

  if (usedPctOfXmx >= 65) {
    return {
      usedPctOfXmx,
      allocatedPctOfXmx,
      headroomMb,
      tier: 'moderate',
      label: 'Moderate Load',
      guidance: `Balanced heap footprint within -Xmx${safeXmx}M (${headroomMb} MB headroom).`,
    };
  }

  return {
    usedPctOfXmx,
    allocatedPctOfXmx,
    headroomMb,
    tier: 'optimal',
    label: 'Optimal Efficiency',
    guidance: `Healthy heap margin inside -Xmx${safeXmx}M with ${headroomMb} MB free before cap.`,
  };
}

export function formatUptime(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  const pad = (n: number) => n.toString().padStart(2, '0');
  if (hrs > 0) {
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

export function filterMods(
  mods: AgretiumMod[],
  options: { category: 'All' | ModCategory; search: string }
): AgretiumMod[] {
  const query = options.search.trim().toLowerCase();
  return mods.filter((mod) => {
    const matchesCategory = options.category === 'All' || mod.category === options.category;
    if (!matchesCategory) return false;
    if (!query) return true;
    return (
      mod.name.toLowerCase().includes(query) ||
      mod.description.toLowerCase().includes(query) ||
      mod.category.toLowerCase().includes(query)
    );
  });
}

export interface ServerTileValidation {
  valid: boolean;
  error?: string;
  normalized?: { name: string; address: string; shortCode: string };
}

export function validateServerTile(input: {
  name: string;
  address: string;
  shortCode: string;
}): ServerTileValidation {
  const name = input.name.trim();
  const address = input.address.trim();
  const shortCode = input.shortCode.trim().toUpperCase();

  if (name.length < 2 || name.length > 32) {
    return { valid: false, error: 'Server name must be 2–32 characters.' };
  }
  if (!/^[a-zA-Z0-9.-]+(:\d{1,5})?$/.test(address) || !address.includes('.')) {
    return { valid: false, error: 'Enter a valid server address (e.g. play.example.net).' };
  }
  if (shortCode.length < 1 || shortCode.length > 4) {
    return { valid: false, error: 'Tile badge code must be 1–4 characters.' };
  }

  return {
    valid: true,
    normalized: { name, address, shortCode },
  };
}

export const LOCAL_ACCOUNTS_STORAGE_KEY = 'agretium_local_accounts';

export function generateOfflineUuid(username: string): string {
  let h1 = 0x811c9dc5;
  let h2 = 0xdeadbeef;
  for (let i = 0; i < username.length; i += 1) {
    const code = username.charCodeAt(i);
    h1 = Math.imul(h1 ^ code, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ (code + i), 0x85ebca6b) >>> 0;
  }
  const part1 = h1.toString(16).padStart(8, '0');
  const part2 = (h2 >>> 16).toString(16).padStart(4, '0');
  const part3 = `3${(h2 & 0x0fff).toString(16).padStart(3, '0')}`;
  const part4 = `8${((h1 ^ h2) & 0x0fff).toString(16).padStart(3, '0')}`;
  const part5 = `${h1.toString(16).padStart(8, '0')}${(h2 & 0xffff).toString(16).padStart(4, '0')}`;
  return `${part1}-${part2}-${part3}-${part4}-${part5}`;
}

export interface OfflineAccountValidation {
  valid: boolean;
  error?: string;
  profile?: AccountProfile;
}

export function createOfflineAccount(
  username: string,
  existingAccounts: AccountProfile[]
): OfflineAccountValidation {
  const trimmed = username.trim();
  if (trimmed.length < 3 || trimmed.length > 16 || !/^[a-zA-Z0-9_]+$/.test(trimmed)) {
    return {
      valid: false,
      error: 'Username must be 3–16 characters (letters, numbers, underscores).',
    };
  }
  if (existingAccounts.some((a) => a.username.toLowerCase() === trimmed.toLowerCase())) {
    return {
      valid: false,
      error: 'An account with that username already exists.',
    };
  }
  return {
    valid: true,
    profile: {
      username: trimmed,
      type: 'Offline',
      uuid: generateOfflineUuid(trimmed),
    },
  };
}

export function mergeAccountLists(
  primary: AccountProfile[],
  secondary: AccountProfile[]
): AccountProfile[] {
  const seen = new Set<string>();
  const merged: AccountProfile[] = [];
  for (const acc of [...primary, ...secondary]) {
    const key = acc.username.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      merged.push(acc);
    }
  }
  return merged;
}

export interface ModJarFile {
  fileName: string;
  baseName: string;
  displayName: string;
  enabled: boolean;
  sizeBytes: number;
  isCoreArgentum: boolean;
}

const CORE_ARGENTUM_FILENAMES = new Set(ARGENTUM_MOD_JARS.map((j) => j.fileName.toLowerCase()));

export function validateModJarFileName(fileName: string): {
  valid: boolean;
  sanitized?: string;
  error?: string;
} {
  const trimmed = fileName.trim().split(/[\\/]/).pop() ?? '';
  if (!trimmed || trimmed.includes('..')) {
    return { valid: false, error: 'Invalid mod filename.' };
  }
  if (!/^[a-zA-Z0-9._+-]+\.jar$/i.test(trimmed)) {
    return { valid: false, error: 'Mod file must end with .jar and use standard characters.' };
  }
  if (trimmed.length > 120) {
    return { valid: false, error: 'Mod filename is too long.' };
  }
  return { valid: true, sanitized: trimmed };
}

export function toggleModJarFileName(fileName: string, enable: boolean): string {
  const withoutDisabled = fileName.replace(/\.disabled$/i, '');
  return enable ? withoutDisabled : `${withoutDisabled}.disabled`;
}

export function buildModJarEntry(fileName: string, sizeBytes: number): ModJarFile | null {
  const isDisabled = /\.jar\.disabled$/i.test(fileName);
  const isEnabled = !isDisabled && /\.jar$/i.test(fileName);
  if (!isDisabled && !isEnabled) return null;
  const baseName = fileName.replace(/\.disabled$/i, '');
  return {
    fileName,
    baseName,
    displayName: baseName.replace(/\.jar$/i, ''),
    enabled: isEnabled,
    sizeBytes: Math.max(0, sizeBytes),
    isCoreArgentum: CORE_ARGENTUM_FILENAMES.has(baseName.toLowerCase()),
  };
}

export function formatFileSize(bytes: number): string {
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  if (bytes >= 1024) {
    return `${Math.round(bytes / 1024)} KB`;
  }
  return `${bytes} B`;
}

export function parseServerAddress(address?: string): { host: string; port: number } | null {
  if (!address || !address.trim()) return null;
  const trimmed = address.trim();
  const colonIdx = trimmed.lastIndexOf(':');
  if (colonIdx > 0) {
    const host = trimmed.slice(0, colonIdx).trim();
    const portNum = Number(trimmed.slice(colonIdx + 1).trim());
    if (host && Number.isInteger(portNum) && portNum > 0 && portNum <= 65535) {
      return { host, port: portNum };
    }
  }
  return { host: trimmed, port: 25565 };
}

export function mavenCoordToPath(coord: string): string | null {
  const parts = coord.trim().split(':');
  if (parts.length < 3 || parts.length > 4) return null;
  const group = parts[0].replace(/\./g, '/');
  const artifact = parts[1];
  const versionRaw = parts[2];
  let ext = 'jar';
  let version = versionRaw;
  if (versionRaw.includes('@')) {
    const [v, e] = versionRaw.split('@');
    version = v;
    ext = e || 'jar';
  }
  const classifierPart = parts[3] ? parts[3].split('@')[0] : '';
  const jarName = classifierPart
    ? `${artifact}-${version}-${classifierPart}.${ext}`
    : `${artifact}-${version}.${ext}`;
  return `${group}/${artifact}/${version}/${jarName}`;
}



